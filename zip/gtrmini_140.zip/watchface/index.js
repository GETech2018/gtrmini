﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_calorie_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_temperature_current_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 247,
              y: 61,
              src: 'NoBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 380,
              font_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '3.png',
              hour_centerX: 261,
              hour_centerY: 207,
              hour_posX: 14,
              hour_posY: 144,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '4.png',
              minute_centerX: 261,
              minute_centerY: 208,
              minute_posX: 21,
              minute_posY: 157,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '6.png',
              second_centerX: 261,
              second_centerY: 207,
              second_posX: 22,
              second_posY: 152,
              second_cover_path: '5.png',
              second_cover_x: 245,
              second_cover_y: 191,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 16,
              day_startY: 165,
              day_sc_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              day_tc_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              day_en_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 165,
              src: '17.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 63,
              month_startY: 165,
              month_sc_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              month_tc_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              month_en_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 9,
              y: 231,
              week_en: ["18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              week_tc: ["18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              week_sc: ["18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 196,
              hour_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 59,
              minute_startY: 196,
              minute_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 42,
              y: 185,
              src: '37.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 67,
              am_y: 229,
              am_sc_path: '35.png',
              am_en_path: '35.png',
              pm_x: 67,
              pm_y: 229,
              pm_sc_path: '36.png',
              pm_en_path: '36.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 104,
              font_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              padding: false,
              h_space: 0,
              unit_sc: '40.png',
              unit_tc: '40.png',
              unit_en: '40.png',
              negative_image: '39.png',
              invalid_image: '38.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 57,
              font_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              padding: false,
              h_space: 0,
              unit_sc: '44.png',
              unit_tc: '44.png',
              unit_en: '44.png',
              invalid_image: '42.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 342,
              font_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 293,
              font_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              padding: false,
              h_space: 0,
              invalid_image: '43.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 177,
              y: 16,
              font_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              padding: false,
              h_space: 0,
              unit_sc: '44.png',
              unit_tc: '44.png',
              unit_en: '44.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '45.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 196,
              y: 377,
              src: 'NoBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '3.png',
              hour_centerX: 261,
              hour_centerY: 207,
              hour_posX: 14,
              hour_posY: 144,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '4.png',
              minute_centerX: 261,
              minute_centerY: 208,
              minute_posX: 21,
              minute_posY: 157,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 37,
              day_startY: 182,
              day_sc_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              day_tc_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              day_en_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 29,
              y: 208,
              week_en: ["18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              week_tc: ["18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              week_sc: ["18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 13,
              font_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              padding: false,
              h_space: 0,
              unit_sc: '44.png',
              unit_tc: '44.png',
              unit_en: '44.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
