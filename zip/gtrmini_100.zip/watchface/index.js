﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_frame_animation_1 = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 416,
              // h: 416,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'Main_prew.png', path: 'Main.png' },
                { id: 2, preview: 'Main_2_prew.png', path: 'Main_2.png' },
              ],
              count: 2,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 56,
              font_array: ["weather_numbers_00.png","weather_numbers_01.png","weather_numbers_02.png","weather_numbers_03.png","weather_numbers_04.png","weather_numbers_05.png","weather_numbers_06.png","weather_numbers_07.png","weather_numbers_08.png","weather_numbers_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'weather_numbers_C.png',
              unit_tc: 'weather_numbers_C.png',
              unit_en: 'weather_numbers_C.png',
              negative_image: 'weather_numbers_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 79,
              y: 98,
              image_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 258,
              font_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'Numbers_small_KM.png',
              unit_tc: 'Numbers_small_KM.png',
              unit_en: 'Numbers_small_KM.png',
              imperial_unit_sc: 'Numbers_small_ML.png',
              imperial_unit_tc: 'Numbers_small_ML.png',
              imperial_unit_en: 'Numbers_small_ML.png',
              dot_image: 'Numbers_small_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 258,
              font_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 302,
              year_startY: 142,
              year_sc_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              year_tc_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              year_en_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              year_zero: 1,
              year_space: -3,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 239,
              month_startY: 141,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 87,
              y: 140,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 49,
              day_startY: 142,
              day_sc_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              day_tc_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              day_en_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 303,
              font_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 303,
              font_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 342,
              font_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 16,
              hour_startY: 174,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 174,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: -67,
              second_startY: 171,
              second_array: ["Numbers_big_sec_00.png","Numbers_big_sec_01.png","Numbers_big_sec_02.png","Numbers_big_sec_03.png","Numbers_big_sec_04.png","Numbers_big_sec_05.png","Numbers_big_sec_06.png","Numbers_big_sec_07.png","Numbers_big_sec_08.png","Numbers_big_sec_09.png"],
              second_zero: 1,
              second_space: 152,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Untitled",
              anim_fps: 31,
              anim_size: 124,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 154,
              y: 349,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'Main_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 56,
              font_array: ["weather_numbers_00.png","weather_numbers_01.png","weather_numbers_02.png","weather_numbers_03.png","weather_numbers_04.png","weather_numbers_05.png","weather_numbers_06.png","weather_numbers_07.png","weather_numbers_08.png","weather_numbers_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'weather_numbers_C.png',
              unit_tc: 'weather_numbers_C.png',
              unit_en: 'weather_numbers_C.png',
              negative_image: 'weather_numbers_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 79,
              y: 98,
              image_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 342,
              font_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 16,
              hour_startY: 174,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 174,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: -67,
              second_startY: 171,
              second_array: ["Numbers_big_sec_00.png","Numbers_big_sec_01.png","Numbers_big_sec_02.png","Numbers_big_sec_03.png","Numbers_big_sec_04.png","Numbers_big_sec_05.png","Numbers_big_sec_06.png","Numbers_big_sec_07.png","Numbers_big_sec_08.png","Numbers_big_sec_09.png"],
              second_zero: 1,
              second_space: 152,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 154,
              y: 349,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
