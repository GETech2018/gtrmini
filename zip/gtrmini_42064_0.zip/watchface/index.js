﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 283,
              hour_startY: 169,
              hour_array: ["hm_1.png","hm_2.png","hm_3.png","hm_4.png","hm_5.png","hm_6.png","hm_7.png","hm_8.png","hm_9.png","hm_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 283,
              minute_startY: 213,
              minute_array: ["hm_1.png","hm_2.png","hm_3.png","hm_4.png","hm_5.png","hm_6.png","hm_7.png","hm_8.png","hm_9.png","hm_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 119,
              month_startY: 209,
              month_sc_array: ["mth_1.png","mth_2.png","mth_3.png","mth_4.png","mth_5.png","mth_6.png","mth_7.png","mth_8.png","mth_9.png","mth_10.png","mth_11.png","mth_12.png"],
              month_tc_array: ["mth_1.png","mth_2.png","mth_3.png","mth_4.png","mth_5.png","mth_6.png","mth_7.png","mth_8.png","mth_9.png","mth_10.png","mth_11.png","mth_12.png"],
              month_en_array: ["mth_1.png","mth_2.png","mth_3.png","mth_4.png","mth_5.png","mth_6.png","mth_7.png","mth_8.png","mth_9.png","mth_10.png","mth_11.png","mth_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 87,
              y: 209,
              week_en: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_tc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_sc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 105,
              day_startY: 180,
              day_sc_array: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png","day_10.png"],
              day_tc_array: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png","day_10.png"],
              day_en_array: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png","day_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 4,
              hour_posY: 161,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 4,
              minute_posY: 161,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 15,
              second_posY: 205,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}