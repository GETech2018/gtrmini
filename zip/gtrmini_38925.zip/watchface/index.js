console.log('current filepath: /watchface/index.js');
try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        console.log('current filepath: /watchface/index.js');
        try {
            ((() => {
                const __$$app$$__ = __$$hmAppManager$$__.currentApp;
                function getApp() {
                    return __$$app$$__.app;
                }
                function getCurrentPage() {
                    return __$$app$$__.current && __$$app$$__.current.module;
                }
                const __$$module$$__ = __$$app$$__.current;
                const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
                const {px} = __$$app$$__.__globals__;
                __$$module$$__.module = DeviceRuntimeCore.WatchFace({
                    init_view() {
                        let steps_widget_bg_img = '';
                        let steps_icon_img = '';
                        let steps_widget_arc_progress = '';
                        let weather_widget_bg_img = '';
                        let weather_widget_arc_progress = '';
                        let weather_widget_text_img = '';
                        let weather_widget_img_level = '';
                        let date_widget_bg_img = '';
                        let date_icon_img = '';
                        let date_widget_text_img = '';
                        let week_widget_text_img = '';
                        let steps_button = '';
                        let weather_button = '';
                        let date_button = '';
                        let is_widgets_visible = 1;
                        let week_coord_x = 268;
                        let week_array = [
                            'week/en/1.png',
                            'week/en/2.png',
                            'week/en/3.png',
                            'week/en/4.png',
                            'week/en/5.png',
                            'week/en/6.png',
                            'week/en/7.png'
                        ];
                        let language = hmSetting.getLanguage();
                        if (language == 18) {
                            week_coord_x = 284;
                            week_array[0] = 'week/ua/1.png';
                            week_array[1] = 'week/ua/2.png';
                            week_array[2] = 'week/ua/3.png';
                            week_array[3] = 'week/ua/4.png';
                            week_array[4] = 'week/ua/5.png';
                            week_array[5] = 'week/ua/6.png';
                            week_array[6] = 'week/ua/7.png';
                        }
                        hmUI.createWidget(hmUI.widget.IMG, {
                            x: 0,
                            y: 0,
                            w: 416,
                            h: 416,
                            src: 'bg.png',
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        date_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 292,
                            y: 150,
                            src: 'calendar.png',
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        date_widget_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 258,
                            y: 158,
                            src: 'widget_bg.png',
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        steps_widget_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 58,
                            y: 158,
                            src: 'widget_bg.png',
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        weather_widget_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 158,
                            y: 258,
                            src: 'widget_bg.png',
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        weather_widget_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                            x: 178,
                            y: 276,
                            type: hmUI.data_type.WEATHER_CURRENT,
                            font_array: [
                                'num/0.png',
                                'num/1.png',
                                'num/2.png',
                                'num/3.png',
                                'num/4.png',
                                'num/5.png',
                                'num/6.png',
                                'num/7.png',
                                'num/8.png',
                                'num/9.png'
                            ],
                            align_h: hmUI.align.CENTER_H,
                            h_space: 0,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                            unit_sc: 'weather/sign.png',
                            unit_tc: 'weather/sign.png',
                            unit_en: 'weather/sign.png',
                            negative_image: 'weather/-.png',
                            invalid_image: '--.png',
                            padding: false,
                            isCharacter: false
                        });
                        weather_widget_arc_progress = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                            center_x: 208,
                            center_y: 308,
                            radius: 46,
                            start_angle: -26,
                            end_angle: -334,
                            color: 4293190884,
                            line_width: 8,
                            type: hmUI.data_type.WEATHER_CURRENT,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        steps_widget_arc_progress = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                            center_x: 108,
                            center_y: 208,
                            radius: 46,
                            start_angle: -26,
                            end_angle: -334,
                            color: 4293190884,
                            line_width: 8,
                            type: hmUI.data_type.STEP,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        steps_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 92,
                            y: 152,
                            src: 'steps.png',
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        weather_widget_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                            x: 187,
                            y: 305,
                            image_array: [
                                'weather/0.png',
                                'weather/1.png',
                                'weather/2.png',
                                'weather/3.png',
                                'weather/4.png',
                                'weather/5.png',
                                'weather/6.png',
                                'weather/7.png',
                                'weather/8.png',
                                'weather/9.png',
                                'weather/10.png',
                                'weather/11.png',
                                'weather/12.png',
                                'weather/13.png',
                                'weather/14.png',
                                'weather/15.png',
                                'weather/16.png',
                                'weather/17.png',
                                'weather/18.png',
                                'weather/19.png',
                                'weather/20.png',
                                'weather/21.png',
                                'weather/22.png',
                                'weather/23.png',
                                'weather/24.png',
                                'weather/25.png',
                                'weather/26.png',
                                'weather/27.png',
                                'weather/28.png'
                            ],
                            image_length: 29,
                            type: hmUI.data_type.WEATHER_CURRENT,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        date_widget_text_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                            day_startX: 288,
                            day_startY: 214,
                            day_sc_array: [
                                'num/0.png',
                                'num/1.png',
                                'num/2.png',
                                'num/3.png',
                                'num/4.png',
                                'num/5.png',
                                'num/6.png',
                                'num/7.png',
                                'num/8.png',
                                'num/9.png'
                            ],
                            day_tc_array: [
                                'num/0.png',
                                'num/1.png',
                                'num/2.png',
                                'num/3.png',
                                'num/4.png',
                                'num/5.png',
                                'num/6.png',
                                'num/7.png',
                                'num/8.png',
                                'num/9.png'
                            ],
                            day_en_array: [
                                'num/0.png',
                                'num/1.png',
                                'num/2.png',
                                'num/3.png',
                                'num/4.png',
                                'num/5.png',
                                'num/6.png',
                                'num/7.png',
                                'num/8.png',
                                'num/9.png'
                            ],
                            day_align: hmUI.align.CENTER_H,
                            day_zero: 1,
                            day_follow: 0,
                            day_space: 0,
                            day_is_character: false,
                            enable: false,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        week_widget_text_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                            x: week_coord_x,
                            y: 188,
                            week_en: week_array,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                            hour_centerX: 208,
                            hour_centerY: 208,
                            hour_posX: 24,
                            hour_posY: 134,
                            hour_path: 'hours.png',
                            hour_cover_x: 0,
                            hour_cover_y: 0,
                            minute_centerX: 208,
                            minute_centerY: 208,
                            minute_posX: 10,
                            minute_posY: 194,
                            minute_path: 'minutes.png',
                            minute_cover_x: 0,
                            minute_cover_y: 0,
                            second_centerX: 208,
                            second_centerY: 208,
                            second_posX: 6,
                            second_posY: 194,
                            second_path: 'seconds.png',
                            second_cover_x: 0,
                            second_cover_y: 0,
                            fresh_freqency: 30,
                            enable: false,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                            hour_centerX: 208,
                            hour_centerY: 208,
                            hour_posX: 24,
                            hour_posY: 134,
                            hour_path: 'hours.png',
                            hour_cover_x: 0,
                            hour_cover_y: 0,
                            minute_centerX: 208,
                            minute_centerY: 208,
                            minute_posX: 10,
                            minute_posY: 194,
                            minute_path: 'minutes.png',
                            minute_cover_x: 0,
                            minute_cover_y: 0,
                            enable: false,
                            show_level: hmUI.show_level.ONLY_AOD
                        });
                        hmUI.createWidget(hmUI.widget.BUTTON, {
                            x: 158,
                            y: 0,
                            text: '',
                            w: 100,
                            h: 100,
                            normal_src: 'empty.png',
                            press_src: 'empty.png',
                            show_level: hmUI.show_level.ONLY_NORMAL,
                            longpress_func: () => {
                                is_widgets_visible++;
                                if (is_widgets_visible > 1)
                                    is_widgets_visible = 0;
                                date_button.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                weather_button.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                steps_button.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                steps_widget_bg_img.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                steps_icon_img.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                steps_widget_arc_progress.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                weather_widget_bg_img.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                weather_widget_arc_progress.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                weather_widget_text_img.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                weather_widget_img_level.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                date_widget_bg_img.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                date_icon_img.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                date_widget_text_img.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                                week_widget_text_img.setProperty(hmUI.prop.VISIBLE, is_widgets_visible == 1);
                            }
                        });
                        steps_button = hmUI.createWidget(hmUI.widget.BUTTON, {
                            x: 58,
                            y: 158,
                            text: '',
                            w: 100,
                            h: 100,
                            normal_src: 'empty.png',
                            press_src: 'empty.png',
                            show_level: hmUI.show_level.ONLY_NORMAL,
                            click_func: () => {
                                hmApp.startApp({
                                    url: 'activityAppScreen',
                                    native: true
                                });
                            }
                        });
                        date_button = hmUI.createWidget(hmUI.widget.BUTTON, {
                            x: 258,
                            y: 158,
                            text: '',
                            w: 100,
                            h: 100,
                            normal_src: 'empty.png',
                            press_src: 'empty.png',
                            show_level: hmUI.show_level.ONLY_NORMAL,
                            click_func: () => {
                                hmApp.startApp({
                                    url: 'ScheduleCalScreen',
                                    native: true
                                });
                            }
                        });
                        weather_button = hmUI.createWidget(hmUI.widget.BUTTON, {
                            x: 158,
                            y: 258,
                            text: '',
                            w: 100,
                            h: 100,
                            normal_src: 'empty.png',
                            press_src: 'empty.png',
                            show_level: hmUI.show_level.ONLY_NORMAL,
                            click_func: () => {
                                hmApp.startApp({
                                    url: 'WeatherScreen',
                                    native: true
                                });
                            }
                        });
                    },
                    onInit() {
                        console.log('index page.js on init invoke');
                    },
                    build() {
                        this.init_view();
                        console.log('index page.js on build invoke');
                    },
                    onDestroy() {
                        console.log('index page.js on destroy invoke');
                    }
                });
                ;
            })());
        } catch (e) {
            console.log('Mini Program Error', e);
            e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
        }
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}