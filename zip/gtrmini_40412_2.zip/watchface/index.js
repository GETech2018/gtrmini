﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_frame_animation_1 = ''
        let normal_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 296,
              y: 184,
              image_array: ["wt_1.png","wt_2.png","wt_3.png","wt_4.png","wt_5.png","wt_6.png","wt_7.png","wt_8.png","wt_9.png","wt_10.png","wt_11.png","wt_12.png","wt_13.png","wt_14.png","wt_15.png","wt_16.png","wt_17.png","wt_18.png","wt_19.png","wt_20.png","wt_21.png","wt_22.png","wt_23.png","wt_24.png","wt_25.png","wt_26.png","wt_27.png","wt_28.png","wt_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 146,
              font_array: ["tp_0069.png","tp_0070.png","tp_0071.png","tp_0072.png","tp_0073.png","tp_0074.png","tp_0075.png","tp_0076.png","tp_0077.png","tp_0078.png"],
              padding: false,
              h_space: 0,
              negative_image: 'tp_minus.png',
              invalid_image: 'tp_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 244,
              font_array: ["tp_0069.png","tp_0070.png","tp_0071.png","tp_0072.png","tp_0073.png","tp_0074.png","tp_0075.png","tp_0076.png","tp_0077.png","tp_0078.png"],
              padding: false,
              h_space: 0,
              negative_image: 'tp_minus.png',
              invalid_image: 'tp_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 196,
              font_array: ["tp_0069.png","tp_0070.png","tp_0071.png","tp_0072.png","tp_0073.png","tp_0074.png","tp_0075.png","tp_0076.png","tp_0077.png","tp_0078.png"],
              padding: false,
              h_space: 0,
              negative_image: 'tp_minus.png',
              invalid_image: 'tp_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 360,
              font_array: ["inf_0050.png","inf_0051.png","inf_0052.png","inf_0053.png","inf_0054.png","inf_0055.png","inf_0056.png","inf_0057.png","inf_0058.png","inf_0059.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 286,
              font_array: ["inf_0050.png","inf_0051.png","inf_0052.png","inf_0053.png","inf_0054.png","inf_0055.png","inf_0056.png","inf_0057.png","inf_0058.png","inf_0059.png"],
              padding: false,
              h_space: -2,
              dot_image: 'inf_0061.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 104,
              font_array: ["inf_0050.png","inf_0051.png","inf_0052.png","inf_0053.png","inf_0054.png","inf_0055.png","inf_0056.png","inf_0057.png","inf_0058.png","inf_0059.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'inf_0060.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 29,
              font_array: ["inf_0050.png","inf_0051.png","inf_0052.png","inf_0053.png","inf_0054.png","inf_0055.png","inf_0056.png","inf_0057.png","inf_0058.png","inf_0059.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 26,
              y: 142,
              week_en: ["w_0062.png","w_0063.png","w_0064.png","w_0065.png","w_0066.png","w_0067.png","w_0068.png"],
              week_tc: ["w_0062.png","w_0063.png","w_0064.png","w_0065.png","w_0066.png","w_0067.png","w_0068.png"],
              week_sc: ["w_0062.png","w_0063.png","w_0064.png","w_0065.png","w_0066.png","w_0067.png","w_0068.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 26,
              month_startY: 236,
              month_sc_array: ["mt_0079.png","mt_0080.png","mt_0081.png","mt_0082.png","mt_0083.png","mt_0084.png","mt_0085.png","mt_0086.png","mt_0087.png","mt_0088.png","mt_0089.png","mt_0090.png"],
              month_tc_array: ["mt_0079.png","mt_0080.png","mt_0081.png","mt_0082.png","mt_0083.png","mt_0084.png","mt_0085.png","mt_0086.png","mt_0087.png","mt_0088.png","mt_0089.png","mt_0090.png"],
              month_en_array: ["mt_0079.png","mt_0080.png","mt_0081.png","mt_0082.png","mt_0083.png","mt_0084.png","mt_0085.png","mt_0086.png","mt_0087.png","mt_0088.png","mt_0089.png","mt_0090.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 8,
              day_startY: 188,
              day_sc_array: ["dia_0069.png","dia_0070.png","dia_0071.png","dia_0072.png","dia_0073.png","dia_0074.png","dia_0075.png","dia_0076.png","dia_0077.png","dia_0078.png"],
              day_tc_array: ["dia_0069.png","dia_0070.png","dia_0071.png","dia_0072.png","dia_0073.png","dia_0074.png","dia_0075.png","dia_0076.png","dia_0077.png","dia_0078.png"],
              day_en_array: ["dia_0069.png","dia_0070.png","dia_0071.png","dia_0072.png","dia_0073.png","dia_0074.png","dia_0075.png","dia_0076.png","dia_0077.png","dia_0078.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 71,
              y: 5,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "ani",
              anim_fps: 15,
              anim_size: 48,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 162,
              hour_startY: 78,
              hour_array: ["hm_000.png","hm_001.png","hm_002.png","hm_003.png","hm_004.png","hm_005.png","hm_006.png","hm_007.png","hm_008.png","hm_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 162,
              minute_startY: 219,
              minute_array: ["hm_000.png","hm_001.png","hm_002.png","hm_003.png","hm_004.png","hm_005.png","hm_006.png","hm_007.png","hm_008.png","hm_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 156,
              y: 352,
              w: 100,
              h: 64,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 73,
              w: 100,
              h: 64,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 157,
              y: 218,
              w: 100,
              h: 124,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 157,
              y: 77,
              w: 100,
              h: 124,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 12,
              y: 235,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bt_trans.png',
              normal_src: 'bt_trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 7,
              y: 147,
              w: 100,
              h: 83,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bt_trans.png',
              normal_src: 'bt_trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 358,
              y: 146,
              w: 48,
              h: 124,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bt_trans.png',
              normal_src: 'bt_trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 280,
              y: 170,
              w: 75,
              h: 83,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bt_trans.png',
              normal_src: 'bt_trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 280,
              y: 274,
              w: 75,
              h: 83,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bt_trans.png',
              normal_src: 'bt_trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 160,
              y: 0,
              w: 100,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bt_trans.png',
              normal_src: 'bt_trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}