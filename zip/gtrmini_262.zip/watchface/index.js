﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_year = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_sun_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_image_img = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_TextRotate = new Array(5);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 14;
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 263,
              src: 'bt_on.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 269,
              y: 263,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 189,
              day_startY: 316,
              day_sc_array: ["bnum_1.png","bnum_2.png","bnum_3.png","bnum_4.png","bnum_5.png","bnum_6.png","bnum_7.png","bnum_8.png","bnum_9.png","bnum_10.png"],
              day_tc_array: ["bnum_1.png","bnum_2.png","bnum_3.png","bnum_4.png","bnum_5.png","bnum_6.png","bnum_7.png","bnum_8.png","bnum_9.png","bnum_10.png"],
              day_en_array: ["bnum_1.png","bnum_2.png","bnum_3.png","bnum_4.png","bnum_5.png","bnum_6.png","bnum_7.png","bnum_8.png","bnum_9.png","bnum_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 164,
              year_startY: 136,
              year_sc_array: ["snum_1.png","snum_2.png","snum_3.png","snum_4.png","snum_5.png","snum_6.png","snum_7.png","snum_8.png","snum_9.png","snum_10.png"],
              year_tc_array: ["snum_1.png","snum_2.png","snum_3.png","snum_4.png","snum_5.png","snum_6.png","snum_7.png","snum_8.png","snum_9.png","snum_10.png"],
              year_en_array: ["snum_1.png","snum_2.png","snum_3.png","snum_4.png","snum_5.png","snum_6.png","snum_7.png","snum_8.png","snum_9.png","snum_10.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 223,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_15.png',
              unit_tc: 'num_15.png',
              unit_en: 'num_15.png',
              negative_image: 'num_14.png',
              invalid_image: 'num_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 222,
              image_array: ["weather_icon_01w.png","weather_icon_02w.png","weather_icon_03w.png","weather_icon_04w.png","weather_icon_05w.png","weather_icon_06w.png","weather_icon_07w.png","weather_icon_08w.png","weather_icon_09w.png","weather_icon_10w.png","weather_icon_11w.png","weather_icon_12w.png","weather_icon_13w.png","weather_icon_14w.png","weather_icon_15w.png","weather_icon_16w.png","weather_icon_17w.png","weather_icon_18w.png","weather_icon_19w.png","weather_icon_20w.png","weather_icon_21w.png","weather_icon_22w.png","weather_icon_23w.png","weather_icon_24w.png","weather_icon_25w.png","weather_icon_26w.png","weather_icon_27w.png","weather_icon_28w.png","weather_icon_29w.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 252,
              y: 59,
              src: 'vs_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 59,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 252,
              y: 59,
              image_array: ["vs_1.png","vs_2.png"],
              image_length: 2,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 90,
              font_array: ["bignum_1.png","bignum_2.png","bignum_3.png","bignum_4.png","bignum_5.png","bignum_6.png","bignum_7.png","bignum_8.png","bignum_9.png","bignum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 101,
              src: 'step_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'st_pointer.png',
              center_x: 129,
              center_y: 105,
              x: 62,
              y: 62,
              start_angle: 0,
              end_angle: 126,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 241,
              month_startY: 137,
              month_sc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 79,
              // center_y: 207,
              // start_angle: -34,
              // end_angle: -142,
              // radius: 71,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 79,
              center_y: 207,
              start_angle: -34,
              end_angle: -142,
              radius: 66,
              line_width: 10,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 191,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 285,
              image_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png","m13.png","m14.png","m15.png","m16.png","m17.png","m18.png","m19.png","m20.png","m21.png","m22.png","m23.png","m24.png","m25.png","m26.png","m27.png","m28.png","m29.png","m30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 85,
              // y: 320,
              // font_array: ["bt_num_1.png","bt_num_2.png","bt_num_3.png","bt_num_4.png","bt_num_5.png","bt_num_6.png","bt_num_7.png","bt_num_8.png","bt_num_9.png","bt_num_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 48,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'bt_num_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'bt_num_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'bt_num_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'bt_num_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'bt_num_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'bt_num_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'bt_num_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'bt_num_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'bt_num_9.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'bt_num_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 416,
                h: 416,
                center_x: 85,
                center_y: 320,
                pos_x: 85,
                pos_y: 320,
                angle: 48,
                src: 'bt_num_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 79,
              y: 267,
              image_array: ["zone_1.png","zone_2.png","zone_3.png","zone_4.png","zone_5.png","zone_6.png","zone_7.png","zone_8.png","zone_9.png","zone_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 243,
              hour_startY: 173,
              hour_array: ["dn_num_1.png","dn_num_2.png","dn_num_3.png","dn_num_4.png","dn_num_5.png","dn_num_6.png","dn_num_7.png","dn_num_8.png","dn_num_9.png","dn_num_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dn_num_11.png',
              hour_unit_tc: 'dn_num_11.png',
              hour_unit_en: 'dn_num_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["dn_num_1.png","dn_num_2.png","dn_num_3.png","dn_num_4.png","dn_num_5.png","dn_num_6.png","dn_num_7.png","dn_num_8.png","dn_num_9.png","dn_num_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 208,
              hour_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 208,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_1.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 208,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'aod_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 269,
              y: 263,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 243,
              hour_startY: 173,
              hour_array: ["dn_num_1.png","dn_num_2.png","dn_num_3.png","dn_num_4.png","dn_num_5.png","dn_num_6.png","dn_num_7.png","dn_num_8.png","dn_num_9.png","dn_num_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dn_num_11.png',
              hour_unit_tc: 'dn_num_11.png',
              hour_unit_en: 'dn_num_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["dn_num_1.png","dn_num_2.png","dn_num_3.png","dn_num_4.png","dn_num_5.png","dn_num_6.png","dn_num_7.png","dn_num_8.png","dn_num_9.png","dn_num_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 208,
              hour_posY: 208,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 208,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 0,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 272,
              y: 160,
              w: 105,
              h: 54,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 2,
              w: 87,
              h: 87,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 278,
              y: 282,
              w: 87,
              h: 87,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 277,
              y: 217,
              w: 87,
              h: 64,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 164,
              w: 87,
              h: 87,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 66,
              y: 36,
              w: 87,
              h: 87,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {

              console.log('update text rotate BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 85 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 79,
                      center_y: 207,
                      start_angle: -34,
                      end_angle: -142,
                      radius: 66,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}