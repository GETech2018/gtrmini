﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_battery_circle_scale = ''
        let normal_step_circle_scale = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 142;
        let normal_timerTextUpdate = undefined;
        let normal_digital_clock_img_time_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'back1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 25,
              // center_y: 207,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 22,
              // line_width: 22,
              // line_cap: Flat,
              // color: 0xFF82996B,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 25,
              center_y: 207,
              start_angle: 0,
              end_angle: 360,
              radius: 11,
              line_width: 22,
              corner_flag: 3,
              color: 0xFF82996B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 390,
              // center_y: 207,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 22,
              // line_width: 22,
              // line_cap: Flat,
              // color: 0xFF9F7F86,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 390,
              center_y: 207,
              start_angle: 0,
              end_angle: 360,
              radius: 11,
              line_width: 22,
              corner_flag: 3,
              color: 0xFF9F7F86,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -250,
              // y: 94,
              // font_array: ["min_00.png","min_01.png","min_02.png","min_03.png","min_04.png","min_05.png","min_06.png","min_07.png","min_08.png","min_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 330,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'min_00.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'min_01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'min_02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'min_03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'min_04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'min_05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'min_06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'min_07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'min_08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'min_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 416,
                h: 416,
                center_x: -250,
                center_y: 94,
                pos_x: -250,
                pos_y: 94,
                angle: 0,
                src: 'min_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 94,
              hour_array: ["hr_00.png","hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png","hr_07.png","hr_08.png","hr_09.png"],
              hour_zero: 1,
              hour_space: 330,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hd_min.png',
              minute_centerX: 207,
              minute_centerY: 207,
              minute_posX: 12,
              minute_posY: 205,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hd_hr.png',
              hour_centerX: 207,
              hour_centerY: 207,
              hour_posX: 12,
              hour_posY: 205,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -250 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + 330;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 25,
                      center_y: 207,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 11,
                      line_width: 22,
                      corner_flag: 3,
                      color: 0xFF82996B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 390,
                      center_y: 207,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 11,
                      line_width: 22,
                      corner_flag: 3,
                      color: 0xFF9F7F86,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}