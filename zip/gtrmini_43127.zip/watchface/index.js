﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sunrise_TextCircle = new Array(5);
        let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextCircle_img_width = 15;
        let normal_sunrise_TextCircle_img_height = 21;
        let normal_sunrise_TextCircle_unit = null;
        let normal_sunrise_TextCircle_unit_width = 22;
        let normal_sunrise_TextCircle_dot_width = 12;
        let normal_sunset_TextCircle = new Array(5);
        let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunset_TextCircle_img_width = 15;
        let normal_sunset_TextCircle_img_height = 21;
        let normal_sunset_TextCircle_unit = null;
        let normal_sunset_TextCircle_unit_width = 22;
        let normal_sunset_TextCircle_dot_width = 12;
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_day_text_font = ''
        let normal_heart_rate_image_progress_img_progress = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 15;
        let normal_heart_rate_TextCircle_img_height = 21;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 15;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 24;
        let normal_temperature_current_TextRotate_dot_width = 12;
        let normal_city_name_text = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_current_text_font = ''
        let idle_day_text_font = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: CaviarDreams.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 414,
              y: 414,
              w: 530,
              h: 55,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/CaviarDreams.ttf',
              color: 0xFFE2E2E2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: CaviarDreams.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 414,
              y: 414,
              w: 434,
              h: 44,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/CaviarDreams.ttf',
              color: 0xFFCACACA,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: advanced_dot_digital-7.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 414,
              y: 414,
              w: 882,
              h: 93,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/advanced_dot_digital-7.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: advanced_dot_digital-7.ttf; FontSize: 60
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 414,
              y: 414,
              w: 1323,
              h: 140,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/advanced_dot_digital-7.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: advanced_dot_digital-7.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 414,
              y: 414,
              w: 783,
              h: 82,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/advanced_dot_digital-7.ttf',
              color: 0xFFCA0000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: JdLcdRoundedRegular-vXwE.ttf; FontSize: 80
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 414,
              y: 414,
              w: 794,
              h: 78,
              text_size: 80,
              char_space: 0,
              line_space: 0,
              font: 'fonts/JdLcdRoundedRegular-vXwE.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: JdLcdRoundedRegular-vXwE.ttf; FontSize: 82
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 414,
              y: 414,
              w: 816,
              h: 79,
              text_size: 82,
              char_space: 0,
              line_space: 0,
              font: 'fonts/JdLcdRoundedRegular-vXwE.ttf',
              color: 0xFFC5C5C5,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 209,
              // circle_center_Y: 209,
              // font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              // radius: 180,
              // angle: 318,
              // char_space_angle: 0,
              // unit: '0011.png',
              // dot_image: '0013.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextCircle_ASCIIARRAY[0] = '0014.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[1] = '0015.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[2] = '0016.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[3] = '0017.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[4] = '0018.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[5] = '0019.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[6] = '0020.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[7] = '0021.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[8] = '0022.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[9] = '0023.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 416,
                h: 416,
                center_x: 209,
                center_y: 209,
                pos_x: 209 - normal_sunrise_TextCircle_img_width / 2,
                pos_y: 209 - 201,
                src: '0014.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_sunrise_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              center_x: 209,
              center_y: 209,
              pos_x: 209 - normal_sunrise_TextCircle_unit_width / 2,
              pos_y: 209 - 201,
              src: '0011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_sunrise_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 209,
              // circle_center_Y: 209,
              // font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              // radius: 180,
              // angle: 16,
              // char_space_angle: 0,
              // unit: '0012.png',
              // dot_image: '0013.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextCircle_ASCIIARRAY[0] = '0014.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[1] = '0015.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[2] = '0016.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[3] = '0017.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[4] = '0018.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[5] = '0019.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[6] = '0020.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[7] = '0021.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[8] = '0022.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[9] = '0023.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 416,
                h: 416,
                center_x: 209,
                center_y: 209,
                pos_x: 209 - normal_sunset_TextCircle_img_width / 2,
                pos_y: 209 - 201,
                src: '0014.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_sunset_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              center_x: 209,
              center_y: 209,
              pos_x: 209 - normal_sunset_TextCircle_unit_width / 2,
              pos_y: 209 - 201,
              src: '0012.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_sunset_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 75,
              y: 170,
              src: '0024.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 320,
              y: 170,
              week_en: ["240.png","241.png","242.png","243.png","244.png","245.png","246.png"],
              week_tc: ["240.png","241.png","242.png","243.png","244.png","245.png","246.png"],
              week_sc: ["240.png","241.png","242.png","243.png","244.png","245.png","246.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 314,
              y: 192,
              w: 80,
              h: 80,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/CaviarDreams.ttf',
              color: 0xFFE2E2E2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [238,238,238,238,238,238],
              y: [370,370,370,370,370,370],
              image_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 208,
              // circle_center_Y: 208,
              // font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              // radius: 194,
              // angle: 148,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = '0014.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = '0015.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = '0016.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = '0017.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = '0018.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = '0019.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = '0020.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = '0021.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = '0022.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = '0023.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 416,
                h: 416,
                center_x: 208,
                center_y: 208,
                pos_x: 208 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 208 + 173,
                src: '0014.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 139,
              y: 368,
              image_array: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 115,
              // y: 355,
              // font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 38,
              // unit_en: '0043.png',
              // negative_image: '0013.png',
              // dot_image: '0013.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = '0014.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = '0015.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = '0016.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = '0017.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = '0018.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = '0019.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = '0020.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = '0021.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = '0022.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = '0023.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 416,
                h: 416,
                center_x: 115,
                center_y: 355,
                pos_x: 115,
                pos_y: 355,
                angle: 38,
                src: '0014.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              center_x: 115,
              center_y: 355,
              pos_x: 115,
              pos_y: 355,
              angle: 38,
              src: '0043.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 148,
              y: 332,
              w: 120,
              h: 27,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              color: 0xFFA40000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 37,
              y: 188,
              w: 90,
              h: 60,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/CaviarDreams.ttf',
              color: 0xFFCACACA,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [0,0,0,0,0,0,0,0,0,0],
              y: [120,120,120,120,120,120,120,120,120,120],
              image_array: ["b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png","b91.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 95,
              y: 204,
              w: 120,
              h: 135,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/advanced_dot_digital-7.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 166,
              y: 220,
              w: 120,
              h: 135,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/advanced_dot_digital-7.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 274,
              y: 216,
              w: 80,
              h: 100,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/advanced_dot_digital-7.ttf',
              color: 0xFFCA0000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_2.png',
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 28,
              hour_posY: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_2.png',
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 28,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 28,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '0000_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 72,
              y: 70,
              src: '0025.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 72,
              y: 112,
              src: '0024.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 305,
              y: 150,
              week_en: ["240.png","241.png","242.png","243.png","244.png","245.png","246.png"],
              week_tc: ["240.png","241.png","242.png","243.png","244.png","245.png","246.png"],
              week_sc: ["240.png","241.png","242.png","243.png","244.png","245.png","246.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 30,
              y: 152,
              w: 134,
              h: 89,
              text_size: 80,
              char_space: 0,
              line_space: 0,
              font: 'fonts/JdLcdRoundedRegular-vXwE.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 236,
              y: 165,
              w: 134,
              h: 89,
              text_size: 82,
              char_space: 0,
              line_space: 0,
              font: 'fonts/JdLcdRoundedRegular-vXwE.ttf',
              color: 0xFFC5C5C5,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 50,
              hour_array: ["220.png","221.png","222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 110,
              minute_startY: 225,
              minute_array: ["220.png","221.png","222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_2.png',
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 28,
              hour_posY: 209,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_2.png',
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 28,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 213,
              y: 349,
              w: 126,
              h: 64,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 121,
              w: 101,
              h: 178,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 174,
              w: 71,
              h: 71,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 64,
              y: 334,
              w: 133,
              h: 80,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 137,
              y: 9,
              w: 141,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_dndScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text circle sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_sunrise_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 318;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_sunrise_TextCircle_img_angle = 0;
                  let normal_sunrise_TextCircle_dot_img_angle = 0;
                  let normal_sunrise_TextCircle_unit_angle = 0;
                  normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width/2, 180));
                  normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width/2, 180));
                  normal_sunrise_TextCircle_unit_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_unit_width/2, 180));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 209 - normal_sunrise_TextCircle_img_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 209 - normal_sunrise_TextCircle_dot_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, '0013.png');
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_sunrise_TextCircle_unit_angle;
                  normal_sunrise_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_sunrise_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text circle sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_circle_string = String(sunset_hour) + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_sunset_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 16;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_sunset_TextCircle_img_angle = 0;
                  let normal_sunset_TextCircle_dot_img_angle = 0;
                  let normal_sunset_TextCircle_unit_angle = 0;
                  normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width/2, 180));
                  normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width/2, 180));
                  normal_sunset_TextCircle_unit_angle = toDegree(Math.atan2(normal_sunset_TextCircle_unit_width/2, 180));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 209 - normal_sunset_TextCircle_img_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 209 - normal_sunset_TextCircle_dot_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, '0013.png');
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_sunset_TextCircle_unit_angle;
                  normal_sunset_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_sunset_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 328;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 194));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 1 * (normal_heart_rate_circle_string.length - 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 208 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  img_offset -= normal_temperature_current_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 115 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 115 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, '0013.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 115 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}