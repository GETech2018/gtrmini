﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_stand_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg = ''
        let idle_stand_icon_img = ''
        let idle_temperature_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let editableTimePointers = ''
        let editableTimePointers_cover_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 416,
              // h: 416,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'main_prew_green.png', path: 'main_green.png' },
                { id: 2, preview: 'main_prew_yellow.png', path: 'main_yellow.png' },
                { id: 3, preview: 'main_prew_orange.png', path: 'main_orange.png' },
                { id: 4, preview: 'main_prew_lemon.png', path: 'main_lemon.png' },
                { id: 5, preview: 'main_prew_blue.png', path: 'main_blue.png' },
                { id: 6, preview: 'main_prew_bred.png', path: 'main_bred.png' },
                { id: 7, preview: 'main_prew_beige.png', path: 'main_beige.png' },
                { id: 8, preview: 'main_prew_whitered.png', path: 'main_whitered.png' },
                { id: 9, preview: 'bg_edit_9_preview.png', path: 'main_gold.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 179,
              font_array: ["Numbers_weather_00.png","Numbers_weather_01.png","Numbers_weather_02.png","Numbers_weather_03.png","Numbers_weather_04.png","Numbers_weather_05.png","Numbers_weather_06.png","Numbers_weather_07.png","Numbers_weather_08.png","Numbers_weather_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Numbers_weather_C.png',
              unit_tc: 'Numbers_weather_C.png',
              unit_en: 'Numbers_weather_C.png',
              negative_image: 'Numbers_weather_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 179,
              font_array: ["Numbers_steps_00.png","Numbers_steps_01.png","Numbers_steps_02.png","Numbers_steps_03.png","Numbers_steps_04.png","Numbers_steps_05.png","Numbers_steps_06.png","Numbers_steps_07.png","Numbers_steps_08.png","Numbers_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 224,
              font_array: ["Numbers_steps_00.png","Numbers_steps_01.png","Numbers_steps_02.png","Numbers_steps_03.png","Numbers_steps_04.png","Numbers_steps_05.png","Numbers_steps_06.png","Numbers_steps_07.png","Numbers_steps_08.png","Numbers_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 224,
              font_array: ["Numbers_steps_00.png","Numbers_steps_01.png","Numbers_steps_02.png","Numbers_steps_03.png","Numbers_steps_04.png","Numbers_steps_05.png","Numbers_steps_06.png","Numbers_steps_07.png","Numbers_steps_08.png","Numbers_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 86,
              y: 197,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 25,
              day_startY: 197,
              day_sc_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              day_tc_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              day_en_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 185,
              am_y: 86,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 185,
              pm_y: 86,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 254,
              hour_startY: 197,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 327,
              minute_startY: 197,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 191,
              second_startY: 318,
              second_array: ["Numbers_sec_00.png","Numbers_sec_01.png","Numbers_sec_02.png","Numbers_sec_03.png","Numbers_sec_04.png","Numbers_sec_05.png","Numbers_sec_06.png","Numbers_sec_07.png","Numbers_sec_08.png","Numbers_sec_09.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 154,
              y: 332,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              color: '0xFFCFCFCF',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 179,
              font_array: ["Numbers_weather_00.png","Numbers_weather_01.png","Numbers_weather_02.png","Numbers_weather_03.png","Numbers_weather_04.png","Numbers_weather_05.png","Numbers_weather_06.png","Numbers_weather_07.png","Numbers_weather_08.png","Numbers_weather_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Numbers_weather_C.png',
              unit_tc: 'Numbers_weather_C.png',
              unit_en: 'Numbers_weather_C.png',
              negative_image: 'Numbers_weather_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 179,
              font_array: ["Numbers_steps_00.png","Numbers_steps_01.png","Numbers_steps_02.png","Numbers_steps_03.png","Numbers_steps_04.png","Numbers_steps_05.png","Numbers_steps_06.png","Numbers_steps_07.png","Numbers_steps_08.png","Numbers_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 224,
              font_array: ["Numbers_steps_00.png","Numbers_steps_01.png","Numbers_steps_02.png","Numbers_steps_03.png","Numbers_steps_04.png","Numbers_steps_05.png","Numbers_steps_06.png","Numbers_steps_07.png","Numbers_steps_08.png","Numbers_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 224,
              font_array: ["Numbers_steps_00.png","Numbers_steps_01.png","Numbers_steps_02.png","Numbers_steps_03.png","Numbers_steps_04.png","Numbers_steps_05.png","Numbers_steps_06.png","Numbers_steps_07.png","Numbers_steps_08.png","Numbers_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 86,
              y: 197,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 25,
              day_startY: 197,
              day_sc_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              day_tc_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              day_en_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 185,
              am_y: 86,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 185,
              pm_y: 86,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 254,
              hour_startY: 197,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 327,
              minute_startY: 197,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 154,
              y: 332,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 23,
                    posY: 211,
                    path: 'Hand_sec_green.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 40,
                    posY: 136,
                    path: 'Hand_hour.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 32,
                    posY: 203,
                    path: 'Hand_minute.png',
                  },
                  preview: 'hands_prew_green.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 23,
                    posY: 211,
                    path: 'Hand_sec_yellow.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 40,
                    posY: 136,
                    path: 'Hand_hour.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 32,
                    posY: 203,
                    path: 'Hand_minute.png',
                  },
                  preview: 'hands_prew_yellow.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 23,
                    posY: 211,
                    path: 'Hand_sec_orange.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 40,
                    posY: 136,
                    path: 'Hand_hour.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 32,
                    posY: 203,
                    path: 'Hand_minute.png',
                  },
                  preview: 'hands_prew_yellow.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 23,
                    posY: 211,
                    path: 'Hand_sec_lemon.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 40,
                    posY: 136,
                    path: 'Hand_hour.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 32,
                    posY: 203,
                    path: 'Hand_minute.png',
                  },
                  preview: 'hands_prew_lemon.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 23,
                    posY: 211,
                    path: 'Hand_sec_blue.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 40,
                    posY: 136,
                    path: 'Hand_hour.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 32,
                    posY: 203,
                    path: 'Hand_minute.png',
                  },
                  preview: 'hands_prew_blue.png',
                },
                {
                  id: 6,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 23,
                    posY: 211,
                    path: 'Hand_sec_beige.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 40,
                    posY: 136,
                    path: 'Hand_hour.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 32,
                    posY: 203,
                    path: 'Hand_minute.png',
                  },
                  preview: 'hands_prew_beige.png',
                },
                {
                  id: 7,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 23,
                    posY: 211,
                    path: 'Hand_sec_whitered.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 40,
                    posY: 136,
                    path: 'Hand_hour.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 32,
                    posY: 203,
                    path: 'Hand_minute.png',
                  },
                  preview: 'hands_prew_whitered.png',
                },
                {
                  id: 8,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 23,
                    posY: 211,
                    path: 'Hand_sec_gold.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 40,
                    posY: 136,
                    path: 'Hand_hour.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 32,
                    posY: 203,
                    path: 'Hand_minute.png',
                  },
                  preview: 'pointer_edit_8_preview.png',
                },
              ],
              count: 8,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            editableTimePointers_cover_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 187,
              src: 'dote.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
