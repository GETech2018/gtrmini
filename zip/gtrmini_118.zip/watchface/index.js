﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_stand_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'main_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 146,
              y: 146,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "leftanim",
              anim_fps: 30,
              anim_size: 60,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 172,
              month_startY: 114,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 172,
              y: 61,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 171,
              day_startY: 80,
              day_sc_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              day_tc_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              day_en_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              day_zero: 0,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 193,
              font_array: ["numbers_small_00.png","numbers_small_01.png","numbers_small_02.png","numbers_small_03.png","numbers_small_04.png","numbers_small_05.png","numbers_small_06.png","numbers_small_07.png","numbers_small_08.png","numbers_small_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 193,
              font_array: ["numbers_small_00.png","numbers_small_01.png","numbers_small_02.png","numbers_small_03.png","numbers_small_04.png","numbers_small_05.png","numbers_small_06.png","numbers_small_07.png","numbers_small_08.png","numbers_small_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 187,
              am_y: 340,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 132,
              hour_startY: 304,
              hour_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_align: hmUI.align.LEFT,

              minute_startX: 215,
              minute_startY: 304,
              minute_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 15,
              hour_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_minute.png',
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 15,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 152,
              y: 336,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'main_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 172,
              month_startY: 114,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 172,
              y: 61,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 171,
              day_startY: 80,
              day_sc_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              day_tc_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              day_en_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              day_zero: 0,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 193,
              font_array: ["numbers_small_00.png","numbers_small_01.png","numbers_small_02.png","numbers_small_03.png","numbers_small_04.png","numbers_small_05.png","numbers_small_06.png","numbers_small_07.png","numbers_small_08.png","numbers_small_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 193,
              font_array: ["numbers_small_00.png","numbers_small_01.png","numbers_small_02.png","numbers_small_03.png","numbers_small_04.png","numbers_small_05.png","numbers_small_06.png","numbers_small_07.png","numbers_small_08.png","numbers_small_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 187,
              am_y: 340,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 187,
              pm_y: 340,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 132,
              hour_startY: 304,
              hour_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_align: hmUI.align.LEFT,

              minute_startX: 215,
              minute_startY: 304,
              minute_array: ["numbers_big_00.png","numbers_big_01.png","numbers_big_02.png","numbers_big_03.png","numbers_big_04.png","numbers_big_05.png","numbers_big_06.png","numbers_big_07.png","numbers_big_08.png","numbers_big_09.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 152,
              y: 336,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
