﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_month_pointer_progress_date_pointer = ''
        let editGroup_1  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 416,
              // h: 416,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'b1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'b2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'b3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'b4.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: 'FAQ.png',
              tips_x: 87,
              tips_y: 87,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'small.png',
              center_x: 318,
              center_y: 208,
              x: 19,
              y: 62,
              start_angle: 0,
              end_angle: -180,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 109,
              src: 'Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 132,
              y: 109,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 168,
              y: 109,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 68,
              y: 109,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 341,
              day_startY: 196,
              day_sc_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              day_tc_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              day_en_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              day_zero: 0,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'small.png',
              center_x: 97,
              center_y: 208,
              x: 19,
              y: 62,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'small.png',
              center_x: 208,
              center_y: 320,
              posX: 19,
              posY: 62,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'small.png',
              center_x: 318,
              center_y: 208,
              x: 19,
              y: 62,
              start_angle: 0,
              end_angle: -180,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 109,
              src: 'Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 132,
              y: 109,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 168,
              y: 109,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 68,
              y: 109,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 341,
              day_startY: 196,
              day_sc_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              day_tc_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              day_en_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              day_zero: 0,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'small.png',
              center_x: 97,
              center_y: 208,
              x: 19,
              y: 62,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'small.png',
              center_x: 208,
              center_y: 320,
              posX: 19,
              posY: 62,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              select_image: 'ScPr.png',
              un_select_image: 'ScPr.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'Sc1Pr.png' },
                { type: hmUI.edit_type.CAL, preview: 'Sc2Pr.png' },
                { type: hmUI.edit_type.HEART, preview: 'Sc3Pr.png' },
                { type: hmUI.edit_type.PAI, preview: 'Sc4Pr.png' },
                { type: hmUI.edit_type.STRESS, preview: 'Sc5Pr.png' },
              ],
              count: 5,
              tips_BG: 'FAQScale.png',
              tips_x: -89,
              tips_y: -89,
              tips_width: 2,
              tips_margin: 2,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Sc1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Sc2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Sc3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Sc4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Sc5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'ScPr.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'ScPr.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 21,
                    posY: 198,
                    path: 'S1.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 37,
                    posY: 155,
                    path: 'H1.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 39,
                    posY: 199,
                    path: 'M1.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 21,
                    posY: 198,
                    path: 'S2.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 37,
                    posY: 155,
                    path: 'H2.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 39,
                    posY: 199,
                    path: 'M2.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 21,
                    posY: 198,
                    path: 'S3.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 37,
                    posY: 155,
                    path: 'H3.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 39,
                    posY: 199,
                    path: 'M3.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 21,
                    posY: 198,
                    path: 'S4.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 37,
                    posY: 155,
                    path: 'H4.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 39,
                    posY: 199,
                    path: 'M4.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
              ],
              count: 4,
              default_id: 1,
              fg: 'ScPr.png',
              tips_x: 87,
              tips_y: 271,
              tips_bg: 'FAQ.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
