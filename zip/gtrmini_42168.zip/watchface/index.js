﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_image_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 207,
              second_centerY: 207,
              second_posX: 208,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["mt_01.png","mt_02.png","mt_03.png","mt_04.png","mt_05.png","mt_06.png","mt_07.png","mt_08.png","mt_09.png","mt_10.png","mt_11.png","mt_12.png"],
              month_tc_array: ["mt_01.png","mt_02.png","mt_03.png","mt_04.png","mt_05.png","mt_06.png","mt_07.png","mt_08.png","mt_09.png","mt_10.png","mt_11.png","mt_12.png"],
              month_en_array: ["mt_01.png","mt_02.png","mt_03.png","mt_04.png","mt_05.png","mt_06.png","mt_07.png","mt_08.png","mt_09.png","mt_10.png","mt_11.png","mt_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 198,
              day_startY: 387,
              day_sc_array: ["info_1.png","info_2.png","info_3.png","info_4.png","info_5.png","info_6.png","info_7.png","info_8.png","info_9.png","info_10.png"],
              day_tc_array: ["info_1.png","info_2.png","info_3.png","info_4.png","info_5.png","info_6.png","info_7.png","info_8.png","info_9.png","info_10.png"],
              day_en_array: ["info_1.png","info_2.png","info_3.png","info_4.png","info_5.png","info_6.png","info_7.png","info_8.png","info_9.png","info_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_tc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_sc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 51,
              font_array: ["info_1.png","info_2.png","info_3.png","info_4.png","info_5.png","info_6.png","info_7.png","info_8.png","info_9.png","info_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'pt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 21,
              font_array: ["info_1.png","info_2.png","info_3.png","info_4.png","info_5.png","info_6.png","info_7.png","info_8.png","info_9.png","info_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 51,
              font_array: ["info_1.png","info_2.png","info_3.png","info_4.png","info_5.png","info_6.png","info_7.png","info_8.png","info_9.png","info_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 127,
              hour_startY: 83,
              hour_array: ["hr_0.png","hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png","hr_6.png","hr_7.png","hr_8.png","hr_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 127,
              minute_startY: 213,
              minute_array: ["hr_0.png","hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png","hr_6.png","hr_7.png","hr_8.png","hr_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 208,
              // center_y: 208,
              // start_angle: -123,
              // end_angle: -57,
              // radius: 202,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF00BEE0,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 208,
              center_y: 208,
              start_angle: -123,
              end_angle: -57,
              radius: 199,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF00BEE0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 33,
              y: 304,
              font_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              padding: false,
              h_space: 0,
              angle: 50,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 208,
                      center_y: 208,
                      start_angle: -123,
                      end_angle: -57,
                      radius: 199,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF00BEE0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}