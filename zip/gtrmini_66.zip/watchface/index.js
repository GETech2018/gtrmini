﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 341,
              y: 112,
              src: '0054.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 143,
              y: 54,
              src: '0057.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 111,
              src: '0052.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 337,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 337,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 286,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 208,
              // center_y: 208,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 208,
              // line_width: 4,
              // color: 0xFF00EC00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 286,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 239,
              month_startY: 108,
              month_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 116,
              y: 109,
              week_en: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_tc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_sc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 109,
              day_sc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              day_tc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              day_en_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 157,
              hour_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: '0058.png',
              hour_unit_tc: '0058.png',
              hour_unit_en: '0058.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 157,
              minute_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 190,
              second_startY: 286,
              second_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 341,
              y: 112,
              src: '0054.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 143,
              y: 54,
              src: '0057.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 111,
              src: '0052.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 337,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 337,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 286,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 208,
              // center_y: 208,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 208,
              // line_width: 4,
              // color: 0xFF00EC00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 286,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 239,
              month_startY: 108,
              month_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 116,
              y: 109,
              week_en: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_tc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_sc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 109,
              day_sc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              day_tc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              day_en_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 157,
              hour_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: '0058.png',
              hour_unit_tc: '0058.png',
              hour_unit_en: '0058.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 157,
              minute_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -90;
                  let end_angle_normal_step = 270;
                  let center_x_normal_step = 208;
                  let center_y_normal_step = 208;
                  let radius_normal_step = 208;
                  let line_width_cs_normal_step = 4;
                  let color_cs_normal_step = 0xFF00EC00;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -90;
                  let end_angle_idle_step = 270;
                  let center_x_idle_step = 208;
                  let center_y_idle_step = 208;
                  let radius_idle_step = 208;
                  let line_width_cs_idle_step = 4;
                  let color_cs_idle_step = 0xFF00EC00;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
