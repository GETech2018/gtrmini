let normal$_$analog_clock$_$time_pointer = ''
let normal$_$image_5c674b503086426098cdbc3364ce0d26 = ''
let normal$_$digital_clock$_$img_time = ''
let normal$_$date$_$img_date = ''
let idle$_$analog_clock$_$time_pointer = ''
let idle$_$image_dfcc18e6686b46b0a0a1f6d52384f9c0 = ''
let idle$_$digital_clock$_$img_time = ''
let idle$_$date$_$img_date = ''

const logger = Logger.getLogger("watchface6");

WatchFace({
  init_view() {
            
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 208,
              minute_posY: 209,
              minute_path: '2.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 208,
              second_posY: 208,
              second_path: '3.png',
              second_cover_x: 0,
              second_cover_y: 0,
              enable: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
            
            normal$_$image_5c674b503086426098cdbc3364ce0d26 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_val: new Date().getHours(),
              hour_zero: 1,
              hour_startX: 157,
              hour_startY: 155,
              hour_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_startX: 279,
              minute_startY: 178,
              minute_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              enable: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 95,
              year_startY: 192,
              year_sc_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              year_tc_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              year_en_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              year_align: hmUI.align.LEFT,
              year_zero: 0,
              year_space: 0,
              year_is_character: false,
              month_startX: 50,
              month_startY: 192,
              month_sc_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              month_tc_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              month_en_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              month_unit_sc: '35.png',
              month_unit_tc: '35.png',
              month_unit_en: '35.png',
              month_align: hmUI.align.LEFT,
              month_zero: 1,
              month_follow: 0,
              month_space: 0,
              month_is_character: false,
              day_startX: 5,
              day_startY: 193,
              day_sc_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              day_tc_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              day_en_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              day_unit_sc: '36.png',
              day_unit_tc: '36.png',
              day_unit_en: '36.png',
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              enable: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
            
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              enable: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
  
            
            idle$_$image_dfcc18e6686b46b0a0a1f6d52384f9c0 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '37.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_val: new Date().getHours(),
              hour_zero: 1,
              hour_startX: 157,
              hour_startY: 155,
              hour_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_startX: 279,
              minute_startY: 178,
              minute_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              enable: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 208,
              month_startY: 290,
              month_sc_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              month_tc_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              month_en_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 1,
              month_follow: 0,
              month_space: 0,
              month_is_character: false,
              day_startX: 150,
              day_startY: 290,
              day_sc_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              day_tc_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              day_en_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              enable: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
  
    
  
    
    
  },

  onInit() {
    logger.log('index page.js on init invoke')
  },

  build() {
    this.init_view()
    logger.log('index page.js on ready invoke')
  },

  onDestroy() {
    logger.log('index page.js on destroy invoke')
  },
});