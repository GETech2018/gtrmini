﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
        
            let heart = hmSensor.createSensor(hmSensor.id.HEART);
            let heartArr = heart.today
            let min_heart = Math.min(...heartArr)
            let max_heart = Math.max(...heartArr)
        
        console.log('user_functions.js');
        // start user_functions.js
        
        // Switch info
        let elementnumber_1 = 1
        let elementnumbers_1 = 1
        let total_elemente = 2
        let total_elementes = 2

        function click_switchINFO() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
            }
        }
        
        function click_switchTSUN() {
            if(elementnumbers_1==total_elementes) {
            elementnumbers_1=1;
                UpdateElementeThree();
                }
            else {
                elementnumbers_1=elementnumbers_1+1;
                if(elementnumbers_1==2) {
                  UpdateElementeFour();
                }
            }
        }

        //heart
        function UpdateElementeOne(){
        normal_g_heart.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_disthrbutton_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_hrdistbutton_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_min_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_max_img.setProperty(hmUI.prop.VISIBLE, true);
        }

        //distance
        function UpdateElementeTwo(){
        normal_g_heart.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_disthrbutton_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_hrdistbutton_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_min_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_max_img.setProperty(hmUI.prop.VISIBLE, false);
        }
        
        //sun
        function UpdateElementeThree(){
        normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        //temp
        function UpdateElementeFour(){
        normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        }
        // end user_functions.js

        let cscreen = 0
        let normal_g_heart = ''
        let normal_heart_rate_text_text_max_img =''
        let normal_heart_rate_text_text_min_img =''
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_circle_scale = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_humidity_text_text_img = ''
        let normal_hrdistbutton_jumpable_img_click = ''
        let normal_calbutton_jumpable_img_click = ''
        let normal_weatherbutton_jumpable_img_click = ''
        let normal_hrdistbutton_img = ''
        let normal_disthrbutton_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 317,
              font_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              padding: false,
              h_space: 0,
              unit_sc: '68.png',
              unit_tc: '68.png',
              unit_en: '68.png',
              negative_image: '67.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 275,
              y: 345,
              src: 'min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 347,
              font_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              padding: false,
              h_space: 0,
              unit_sc: '68.png',
              unit_tc: '68.png',
              unit_en: '68.png',
              negative_image: '67.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 275,
              y: 315,
              src: 'max.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 365,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 4,
              invalid_image: '13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_hrdistbutton_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 114,
              src: 'bg_hr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_clockbg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 45,
              src: 'clockbg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 130,
              center_y: 328,
              start_angle: 0,
              end_angle: 360,
              radius: 28,
              line_width: 7,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFFF0000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_calorie_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 349,
              center_y: 233,
              start_angle: 0,
              end_angle: 360,
              radius: 28,
              line_width: 7,
              corner_flag: 0,
              type: hmUI.data_type.CAL,
              color: 0xFF0061ff,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 57,
              center_y: 233,
              start_angle: 0,
              end_angle: 360,
              radius: 28,
              line_width: 7,
              corner_flag: 0,
              type: hmUI.data_type.BATTERY,
              color: 0xFFFF8C00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_step_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 206,
              center_y: 233,
              start_angle: 0,
              end_angle: 360,
              radius: 28,
              line_width: 7,
              corner_flag: 0,
              type: hmUI.data_type.STEP,
              color: 0xFF00FF00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 305,
              image_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 365,
              font_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              padding: false,
              h_space: 0,
              unit_sc: '68.png',
              unit_tc: '68.png',
              unit_en: '68.png',
              negative_image: '67.png',
              invalid_image: '66.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 180,
              font_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              padding: false,
              h_space: 1,
              unit_sc: '54.png',
              unit_tc: '54.png',
              unit_en: '54.png',
              imperial_unit_sc: '55.png',
              imperial_unit_tc: '55.png',
              imperial_unit_en: '55.png',
              dot_image: '53.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 272,
              font_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 272,
              font_array: ["79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_disthrbutton_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 115,
              src: 'bg_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 110,
              image_array: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              image_length: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 155,
              day_startY: 90,
              day_sc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_tc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_en_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '110.png',
              day_unit_tc: '110.png',
              day_unit_en: '110.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 180,
              month_startY: 90,
              month_sc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              month_tc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              month_en_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '109.png',
              month_unit_tc: '109.png',
              month_unit_en: '109.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 360,
              font_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              padding: false,
              h_space: 0,
              unit_sc: '112.png',
              unit_tc: '112.png',
              unit_en: '112.png',
              invalid_image: '111.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 274,
              y: 357,
              src: '113.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 115,
              y: 89,
              week_en: ["114.png","115.png","116.png","117.png","118.png","119.png","120.png"],
              week_tc: ["114.png","115.png","116.png","117.png","118.png","119.png","120.png"],
              week_sc: ["114.png","115.png","116.png","117.png","118.png","119.png","120.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 272,
              font_array: ["121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png"],
              padding: false,
              h_space: 4,
              unit_sc: '131.png',
              unit_tc: '131.png',
              unit_en: '131.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 310,
              font_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              padding: true,
              h_space: 0,
              invalid_image: '132.png',
              dot_image: '133.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 268,
              y: 305,
              src: '134.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 335,
              font_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              padding: false,
              h_space: 0,
              invalid_image: '135.png',
              dot_image: '136.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 268,
              y: 330,
              src: '137.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 30,
              hour_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '148.png',
              hour_unit_tc: '148.png',
              hour_unit_en: '148.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 172,
              minute_startY: 30,
              minute_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 244,
              second_startY: 33,
              second_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0097.png',
              hour_centerX: 308,
              hour_centerY: 124,
              hour_posX: 9,
              hour_posY: 57,
              hour_cover_path: '0100.png',
              hour_cover_x: 300,
              hour_cover_y: 115,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0098.png',
              minute_centerX: 308,
              minute_centerY: 124,
              minute_posX: 9,
              minute_posY: 56,
              minute_cover_path: '0101.png',
              minute_cover_x: 300,
              minute_cover_y: 115,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0099.png',
              second_centerX: 308,
              second_centerY: 124,
              second_posX: 9,
              second_posY: 75,
              second_cover_path: '0102.png',
              second_cover_x: 300,
              second_cover_y: 115,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            
            

/////////////////////////////////////////////////

           normal_heart_rate_text_text_max_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 115,
	text: max_heart,
              font_array: ["160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png"],
              padding: false,
              h_space: 1,

              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_heart_rate_text_text_min_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 175,
	text: min_heart,
              font_array: ["160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png"],
              padding: false,
              h_space: 1,

              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

///////////////////////////////////////////////////

let intervalId;

function updateDataHeart() {


                                    let heart = hmSensor.createSensor(hmSensor.id.HEART);
                                    let heartArr = heart.today
                                    let min_heart = Math.min(...heartArr)
                                    let max_heart = Math.max(...heartArr)


normal_heart_rate_text_text_max_img.setProperty(hmUI.prop.MORE, {
        x: 45,
        y: 115,
        text: max_heart,
        type: hmUI.data_type.HEART,
        font_array: ["160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png"],
        h_space: 1,
        align_h: hmUI.align.RIGHT,
        padding: false,
        isCharacter: true,
show_level: hmUI.show_level.ONLY_NORMAL,
    });

normal_heart_rate_text_text_min_img.setProperty(hmUI.prop.MORE, {
        x: 45,
        y: 175,
        text: min_heart,
        type: hmUI.data_type.HEART,
        font_array: ["160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png"],
        h_space: 1,
        align_h: hmUI.align.RIGHT,
        padding: false,
        isCharacter: true,
show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

intervalId = setInterval(updateDataHeart, 1000);

///////////////////////////////////////////////////

              normal_g_heart=hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE,{
              x: 75,
              y: 120,
              w: 130,
              h: 55,
              line_width:2,
              type:hmUI.data_type.HEART,
              line_color: 0xc40000,
              curve_style: true,
              show_level:hmUI.show_level.ONLY_NORMAL
              });
              if (cscreen == 0){
              cscreen =1;
              click_switchINFO()
              click_switchTSUN()
              };

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 45,
              y: 75,
              src: '149.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 160,
              y: 30,
              src: '151.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 145,
              src: '150.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 130,
              hour_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '148.png',
              hour_unit_tc: '148.png',
              hour_unit_en: '148.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 132,
              minute_startY: 130,
              minute_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            idle_clockbg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 189,
              y: 145,
              src: 'clockbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });   


            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0097.png',
              hour_centerX: 268,
              hour_centerY: 224,
              hour_posX: 9,
              hour_posY: 57,
              hour_cover_path: '0100.png',
              hour_cover_x: 260,
              hour_cover_y: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0098.png',
              minute_centerX: 268,
              minute_centerY: 224,
              minute_posX: 9,
              minute_posY: 56,
              minute_cover_path: '0101.png',
              minute_cover_x: 260,
              minute_cover_y: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 263,
              y: 190,
              src: '151.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 75,
              y: 189,
              week_en: ["114.png","115.png","116.png","117.png","118.png","119.png","120.png"],
              week_tc: ["114.png","115.png","116.png","117.png","118.png","119.png","120.png"],
              week_sc: ["114.png","115.png","116.png","117.png","118.png","119.png","120.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 115,
              day_startY: 190,
              day_sc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_tc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_en_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '110.png',
              day_unit_tc: '110.png',
              day_unit_en: '110.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 140,
              month_startY: 190,
              month_sc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              month_tc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              month_en_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '109.png',
              month_unit_tc: '109.png',
              month_unit_en: '109.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: bt off,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: bt on,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "bt off"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "bt on"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_calbutton_jumpable_img_click = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 105,
              y: 85,
              w: 110,
              h: 30,
              text: '',
	          normal_src: '0_Empty.png',
	          press_src: '0_Empty.png',
	          click_func: (button_widget) => {
	        hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	         },
	         show_level: hmUI.show_level.ONLY_NORMAL,
	       });

            normal_hrdistbutton_jumpable_img_click = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 125,
              w: 165,
              h: 77,
              text: '',
	          normal_src: '0_Empty.png',
	          press_src: '0_Empty.png',
              click_func: (button_widget) => {
                // switch info
click_switchINFO()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
            
            normal_weatherbutton_jumpable_img_click = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 275,
              y: 300,
              w: 80,
              h: 95,
              text: '',
	          normal_src: '0_Empty.png',
	          press_src: '0_Empty.png',
              click_func: (button_widget) => {
                // switch info
click_switchTSUN()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 200,
              w: 100,
              h: 90,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 269,
              y: 85,
              w: 50,
              h: 110,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 85,
              w: 50,
              h: 110,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 218,
              y: 85,
              w: 50,
              h: 110,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 27,
              w: 180,
              h: 55,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 200,
              w: 100,
              h: 90,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 300,
              w: 90,
              h: 95,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 300,
              w: 80,
              h: 95,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 200,
              w: 130,
              h: 90,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
