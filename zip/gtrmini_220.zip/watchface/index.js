﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'main2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 146,
              month_sc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              month_tc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              month_en_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_circle.png',
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 137,
              minute_posY: 137,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second_circle.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 193,
              second_posY: 193,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 42,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 177,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 275,
              y: 117,
              image_array: ["cal_icon_1.png","cal_icon_2.png","cal_icon_3.png","cal_icon_4.png","cal_icon_5.png","cal_icon_6.png","cal_icon_7.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 87,
              font_array: ["Small_Font_W_01.png","Small_Font_W_02.png","Small_Font_W_03.png","Small_Font_W_04.png","Small_Font_W_05.png","Small_Font_W_06.png","Small_Font_W_07.png","Small_Font_W_08.png","Small_Font_W_09.png","Small_Font_W_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_Font_KM.png',
              unit_tc: 'small_Font_KM.png',
              unit_en: 'small_Font_KM.png',
              imperial_unit_sc: 'small_Font_MI.png',
              imperial_unit_tc: 'small_Font_MI.png',
              imperial_unit_en: 'small_Font_MI.png',
              dot_image: 'small_Font_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 177,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 118,
              image_array: ["Zone_1.png","Zone_2.png","Zone_3.png","Zone_4.png","Zone_5.png","Zone_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 87,
              font_array: ["Small_Font_W_01.png","Small_Font_W_02.png","Small_Font_W_03.png","Small_Font_W_04.png","Small_Font_W_05.png","Small_Font_W_06.png","Small_Font_W_07.png","Small_Font_W_08.png","Small_Font_W_09.png","Small_Font_W_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_symbo_Battery.png',
              unit_tc: 'ACT_symbo_Battery.png',
              unit_en: 'ACT_symbo_Battery.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 111,
              week_en: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              week_tc: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              week_sc: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 188,
              day_startY: 87,
              day_sc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_tc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_en_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 241,
              y: 9,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 151,
              y: 15,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 157,
              hour_startY: 178,
              hour_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'main2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 146,
              month_sc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              month_tc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              month_en_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_circle.png',
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 137,
              minute_posY: 137,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second_circle.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 193,
              second_posY: 193,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 42,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 177,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 275,
              y: 117,
              image_array: ["cal_icon_1.png","cal_icon_2.png","cal_icon_3.png","cal_icon_4.png","cal_icon_5.png","cal_icon_6.png","cal_icon_7.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 87,
              font_array: ["Small_Font_W_01.png","Small_Font_W_02.png","Small_Font_W_03.png","Small_Font_W_04.png","Small_Font_W_05.png","Small_Font_W_06.png","Small_Font_W_07.png","Small_Font_W_08.png","Small_Font_W_09.png","Small_Font_W_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_Font_KM.png',
              unit_tc: 'small_Font_KM.png',
              unit_en: 'small_Font_KM.png',
              imperial_unit_sc: 'small_Font_MI.png',
              imperial_unit_tc: 'small_Font_MI.png',
              imperial_unit_en: 'small_Font_MI.png',
              dot_image: 'small_Font_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 177,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 118,
              image_array: ["Zone_1.png","Zone_2.png","Zone_3.png","Zone_4.png","Zone_5.png","Zone_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 87,
              font_array: ["Small_Font_W_01.png","Small_Font_W_02.png","Small_Font_W_03.png","Small_Font_W_04.png","Small_Font_W_05.png","Small_Font_W_06.png","Small_Font_W_07.png","Small_Font_W_08.png","Small_Font_W_09.png","Small_Font_W_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_symbo_Battery.png',
              unit_tc: 'ACT_symbo_Battery.png',
              unit_en: 'ACT_symbo_Battery.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 111,
              week_en: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              week_tc: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              week_sc: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 188,
              day_startY: 87,
              day_sc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_tc_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_en_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 241,
              y: 9,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 151,
              y: 15,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 157,
              hour_startY: 178,
              hour_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 282,
              w: 49,
              h: 49,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 355,
              w: 48,
              h: 54,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 138,
              y: 4,
              w: 38,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 90,
              w: 50,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 224,
              y: 89,
              w: 44,
              h: 41,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 142,
              w: 70,
              h: 64,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 37,
              y: 133,
              w: 91,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 186,
              w: 96,
              h: 46,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 144,
              y: 48,
              w: 123,
              h: 24,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}