﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_image_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_image_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let editableTimePointers = ''
        let editableTimePointers_cover_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 187,
              second_posY: 187,
              second_cover_path: 'images.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'images.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 309,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 255,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 264,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_4.png',
              unit_tc: 'pointer_4.png',
              unit_en: 'pointer_4.png',
              negative_image: 'pointer_3.png',
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 347,
              y: 122,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 22,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 101,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 50,
              image_array: ["img_cal_1.png","img_cal_2.png","img_cal_3.png","img_cal_4.png","img_cal_5.png","img_cal_6.png","img_cal_7.png","img_cal_8.png"],
              image_length: 8,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 374,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 101,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 50,
              image_array: ["img_step_1.png","img_step_2.png","img_step_3.png","img_step_4.png","img_step_5.png","img_step_6.png","img_step_7.png","img_step_8.png","img_step_9.png","img_step_10.png","img_step_11.png","img_step_12.png","img_step_13.png","img_step_14.png","img_step_15.png","img_step_16.png"],
              image_length: 16,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 355,
              day_startY: 182,
              day_sc_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              day_tc_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              day_en_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 279,
              y: 178,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 285,
              hour_startY: 211,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: 'pointer_1.png',
              hour_unit_tc: 'pointer_1.png',
              hour_unit_en: 'pointer_1.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 343,
              minute_startY: 211,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 187,
              second_posY: 187,
              second_cover_path: 'images.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'images.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 309,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 255,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 264,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_4.png',
              unit_tc: 'pointer_4.png',
              unit_en: 'pointer_4.png',
              negative_image: 'pointer_3.png',
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 347,
              y: 122,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 22,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 101,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 50,
              image_array: ["img_cal_1.png","img_cal_2.png","img_cal_3.png","img_cal_4.png","img_cal_5.png","img_cal_6.png","img_cal_7.png","img_cal_8.png"],
              image_length: 8,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 374,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 101,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 50,
              image_array: ["img_step_1.png","img_step_2.png","img_step_3.png","img_step_4.png","img_step_5.png","img_step_6.png","img_step_7.png","img_step_8.png","img_step_9.png","img_step_10.png","img_step_11.png","img_step_12.png","img_step_13.png","img_step_14.png","img_step_15.png","img_step_16.png"],
              image_length: 16,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 355,
              day_startY: 182,
              day_sc_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              day_tc_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              day_en_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 279,
              y: 178,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 285,
              hour_startY: 211,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: 'pointer_1.png',
              hour_unit_tc: 'pointer_1.png',
              hour_unit_en: 'pointer_1.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 343,
              minute_startY: 211,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 28,
                    posY: 148,
                    path: 'hour.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 28,
                    posY: 194,
                    path: 'minute.png',
                  },
                },
              ],
              count: 1,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            editableTimePointers_cover_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 169,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 178,
              w: 62,
              h: 62,
              src: 'dot.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 269,
              y: 208,
              w: 130,
              h: 31,
              src: 'dot.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 338,
              y: 111,
              w: 52,
              h: 52,
              src: 'dot.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 251,
              w: 52,
              h: 52,
              src: 'dot.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 153,
              y: 0,
              w: 113,
              h: 48,
              src: 'dot.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 223,
              y: 54,
              w: 104,
              h: 104,
              src: 'dot.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 149,
              y: 364,
              w: 117,
              h: 47,
              src: 'dot.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 54,
              w: 104,
              h: 104,
              src: 'dot.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}