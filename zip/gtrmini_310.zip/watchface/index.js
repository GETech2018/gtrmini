﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 87,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -15,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 96,
              minute_startY: 213,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: -15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 182,
              second_startY: 195,
              second_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              second_zero: 1,
              second_space: -3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 253,
              y: 39,
              src: 'stat_b.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 76,
              y: 40,
              src: 'stat_a.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 4,
              second_posY: 205,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 254,
              src: 'ic_kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 254,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 2,
              angle: -21,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 128,
              src: 'ic_puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 140,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 2,
              angle: 21,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 370,
              day_startY: 196,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 5,
              y: 191,
              src: 'ic_year.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 8,
              year_startY: 200,
              year_sc_array: ["dig_y_0.png","dig_y_1.png","dig_y_2.png","dig_y_3.png","dig_y_4.png","dig_y_5.png","dig_y_6.png","dig_y_7.png","dig_y_8.png","dig_y_9.png"],
              year_tc_array: ["dig_y_0.png","dig_y_1.png","dig_y_2.png","dig_y_3.png","dig_y_4.png","dig_y_5.png","dig_y_6.png","dig_y_7.png","dig_y_8.png","dig_y_9.png"],
              year_en_array: ["dig_y_0.png","dig_y_1.png","dig_y_2.png","dig_y_3.png","dig_y_4.png","dig_y_5.png","dig_y_6.png","dig_y_7.png","dig_y_8.png","dig_y_9.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 377,
              y: 258,
              src: 'ic_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 238,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 2,
              angle: 21,
              unit_sc: 'dig_a_pr.png',
              unit_tc: 'dig_a_pr.png',
              unit_en: 'dig_a_pr.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 129,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 2,
              angle: -30,
              unit_sc: 'dig_a_gC.png',
              unit_tc: 'dig_a_gC.png',
              unit_en: 'dig_a_gC.png',
              negative_image: 'dig_a_m.png',
              invalid_image: 'dig_a_v.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 349,
              y: 125,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 39,
              month_startY: 187,
              month_sc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_tc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_en_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 283,
              y: 196,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 331,
              src: 'ic_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 369,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0002_treug.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 96,
              hour_startY: 87,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -15,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 96,
              minute_startY: 213,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: -15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 370,
              day_startY: 196,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 5,
              y: 191,
              src: 'ic_year.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 8,
              year_startY: 200,
              year_sc_array: ["dig_y_0.png","dig_y_1.png","dig_y_2.png","dig_y_3.png","dig_y_4.png","dig_y_5.png","dig_y_6.png","dig_y_7.png","dig_y_8.png","dig_y_9.png"],
              year_tc_array: ["dig_y_0.png","dig_y_1.png","dig_y_2.png","dig_y_3.png","dig_y_4.png","dig_y_5.png","dig_y_6.png","dig_y_7.png","dig_y_8.png","dig_y_9.png"],
              year_en_array: ["dig_y_0.png","dig_y_1.png","dig_y_2.png","dig_y_3.png","dig_y_4.png","dig_y_5.png","dig_y_6.png","dig_y_7.png","dig_y_8.png","dig_y_9.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 39,
              month_startY: 187,
              month_sc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_tc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_en_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 283,
              y: 196,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}