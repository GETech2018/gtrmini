﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stand_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_frame_animation_3 = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 96,
              day_startY: 101,
              day_sc_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              day_tc_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              day_en_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 136,
              month_startY: 102,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 302,
              font_array: ["Numbers2_small_00.png","Numbers2_small_01.png","Numbers2_small_02.png","Numbers2_small_03.png","Numbers2_small_04.png","Numbers2_small_05.png","Numbers2_small_06.png","Numbers2_small_07.png","Numbers2_small_08.png","Numbers2_small_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 302,
              font_array: ["Numbers2_small_00.png","Numbers2_small_01.png","Numbers2_small_02.png","Numbers2_small_03.png","Numbers2_small_04.png","Numbers2_small_05.png","Numbers2_small_06.png","Numbers2_small_07.png","Numbers2_small_08.png","Numbers2_small_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 187,
              y: 102,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 15,
              y: 137,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "rightanim",
              anim_fps: 64,
              anim_size: 32,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 358,
              y: 137,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "leftanim",
              anim_fps: 64,
              anim_size: 32,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_3 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 200,
              y: 176,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Untitled",
              anim_fps: 32,
              anim_size: 32,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 156,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 221,
              minute_startY: 156,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 152,
              y: 330,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'main_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 96,
              day_startY: 101,
              day_sc_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              day_tc_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              day_en_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 136,
              month_startY: 102,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 302,
              font_array: ["Numbers2_small_00.png","Numbers2_small_01.png","Numbers2_small_02.png","Numbers2_small_03.png","Numbers2_small_04.png","Numbers2_small_05.png","Numbers2_small_06.png","Numbers2_small_07.png","Numbers2_small_08.png","Numbers2_small_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 302,
              font_array: ["Numbers2_small_00.png","Numbers2_small_01.png","Numbers2_small_02.png","Numbers2_small_03.png","Numbers2_small_04.png","Numbers2_small_05.png","Numbers2_small_06.png","Numbers2_small_07.png","Numbers2_small_08.png","Numbers2_small_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 187,
              y: 102,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 156,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 221,
              minute_startY: 156,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 152,
              y: 330,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
