﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 14,
              y: 210,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 14,
              y: 179,
              src: 'Sveglia_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 62,
              font_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 281,
              y: 93,
              image_array: ["Passi_00.png","Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 121,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 30,
              month_sc_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              month_tc_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              month_en_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 146,
              day_startY: 30,
              day_sc_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              day_tc_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              day_en_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 30,
              src: 'Nr.Data_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 82,
              y: 62,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 182,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 248,
              y: 228,
              image_array: ["Passi_00.png","Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 248,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 270,
              y: 292,
              image_array: ["BMP_00.png","BMP_01.png","BMP_02.png","BMP_03.png","BMP_04.png","BMP_05.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 333,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 348,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Sist_11.png',
              unit_tc: 'Nr.Sist_11.png',
              unit_en: 'Nr.Sist_11.png',
              imperial_unit_sc: 'Nr.Sist_11.png',
              imperial_unit_tc: 'Nr.Sist_11.png',
              imperial_unit_en: 'Nr.Sist_11.png',
              negative_image: 'Nr.Sist_10.png',
              invalid_image: 'Nr.Sist_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 108,
              hour_array: ["Nr.Ore_00.png","Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 41,
              minute_startY: 216,
              minute_array: ["Nr.Ore_00.png","Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 290,
              second_startY: 310,
              second_array: ["Nr.Sec_00.png","Nr.Sec_01.png","Nr.Sec_02.png","Nr.Sec_03.png","Nr.Sec_04.png","Nr.Sec_05.png","Nr.Sec_06.png","Nr.Sec_07.png","Nr.Sec_08.png","Nr.Sec_09.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 14,
              y: 210,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 14,
              y: 179,
              src: 'Sveglia_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 62,
              font_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 281,
              y: 93,
              image_array: ["Passi_00.png","Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 121,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 30,
              month_sc_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              month_tc_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              month_en_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 146,
              day_startY: 30,
              day_sc_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              day_tc_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              day_en_array: ["Nr.Data_00.png","Nr.Data_01.png","Nr.Data_02.png","Nr.Data_03.png","Nr.Data_04.png","Nr.Data_05.png","Nr.Data_06.png","Nr.Data_07.png","Nr.Data_08.png","Nr.Data_09.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 30,
              src: 'Nr.Data_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 82,
              y: 62,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 182,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 248,
              y: 228,
              image_array: ["Passi_00.png","Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 248,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 270,
              y: 292,
              image_array: ["BMP_00.png","BMP_01.png","BMP_02.png","BMP_03.png","BMP_04.png","BMP_05.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 333,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 348,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Sist_11.png',
              unit_tc: 'Nr.Sist_11.png',
              unit_en: 'Nr.Sist_11.png',
              imperial_unit_sc: 'Nr.Sist_11.png',
              imperial_unit_tc: 'Nr.Sist_11.png',
              imperial_unit_en: 'Nr.Sist_11.png',
              negative_image: 'Nr.Sist_10.png',
              invalid_image: 'Nr.Sist_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 108,
              hour_array: ["Nr.Ore_00.png","Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 41,
              minute_startY: 216,
              minute_array: ["Nr.Ore_00.png","Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}