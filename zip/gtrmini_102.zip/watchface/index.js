﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stand_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'DIGI3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 342,
              font_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 67,
              y: 87,
              week_en: ["dayru_01.png","dayru_02.png","dayru_03.png","dayru_04.png","dayru_05.png","dayru_06.png","dayru_07.png"],
              week_tc: ["dayru_01.png","dayru_02.png","dayru_03.png","dayru_04.png","dayru_05.png","dayru_06.png","dayru_07.png"],
              week_sc: ["dayru_01.png","dayru_02.png","dayru_03.png","dayru_04.png","dayru_05.png","dayru_06.png","dayru_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 170,
              month_startY: 96,
              month_sc_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              month_tc_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              month_en_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'drobgrad.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 126,
              day_startY: 96,
              day_sc_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              day_tc_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              day_en_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 96,
              src: 'stepraz.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 342,
              font_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 305,
              font_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 270,
              font_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'stepproc_01.png',
              unit_tc: 'stepproc_01.png',
              unit_en: 'stepproc_01.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 306,
              font_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              padding: false,
              h_space: 2,
              dot_image: 'stepdot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 270,
              font_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 216,
              y: 77,
              w: 137,
              h: 28,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 134,
              font_array: ["grad_00.png","grad_01.png","grad_02.png","grad_03.png","grad_04.png","grad_05.png","grad_06.png","grad_07.png","grad_08.png","grad_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'gradusgrad.png',
              unit_tc: 'gradusgrad.png',
              unit_en: 'gradusgrad.png',
              negative_image: 'minusgrad.png',
              invalid_image: 'minusgrad.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'drobgrad.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 134,
              font_array: ["grad_00.png","grad_01.png","grad_02.png","grad_03.png","grad_04.png","grad_05.png","grad_06.png","grad_07.png","grad_08.png","grad_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'gradusgrad.png',
              unit_tc: 'gradusgrad.png',
              unit_en: 'gradusgrad.png',
              negative_image: 'minusgrad.png',
              invalid_image: 'minusgrad.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 134,
              src: 'drobgrad.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 100,
              font_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'gradusgrad.png',
              unit_tc: 'gradusgrad.png',
              unit_en: 'gradusgrad.png',
              negative_image: 'min.png',
              invalid_image: 'min.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 104,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 134,
              font_array: ["grad_00.png","grad_01.png","grad_02.png","grad_03.png","grad_04.png","grad_05.png","grad_06.png","grad_07.png","grad_08.png","grad_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 134,
              font_array: ["grad_00.png","grad_01.png","grad_02.png","grad_03.png","grad_04.png","grad_05.png","grad_06.png","grad_07.png","grad_08.png","grad_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'procgrad_01.png',
              unit_tc: 'procgrad_01.png',
              unit_en: 'procgrad_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 57,
              font_array: ["grad_00.png","grad_01.png","grad_02.png","grad_03.png","grad_04.png","grad_05.png","grad_06.png","grad_07.png","grad_08.png","grad_09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'razgrad.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 57,
              font_array: ["grad_00.png","grad_01.png","grad_02.png","grad_03.png","grad_04.png","grad_05.png","grad_06.png","grad_07.png","grad_08.png","grad_09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'razgrad.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sun_01.png',
              center_x: 312,
              center_y: 229,
              x: 24,
              y: -37,
              start_angle: 76,
              end_angle: 251,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 179,
              hour_array: ["clock_00.png","clock_01.png","clock_02.png","clock_03.png","clock_04.png","clock_05.png","clock_06.png","clock_07.png","clock_08.png","clock_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 162,
              minute_startY: 179,
              minute_array: ["clock_00.png","clock_01.png","clock_02.png","clock_03.png","clock_04.png","clock_05.png","clock_06.png","clock_07.png","clock_08.png","clock_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 287,
              second_startY: 200,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 140,
              y: 190,
              src: 'clockraz.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'secstr.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 13,
              second_posY: 203,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 192,
              src: 'blue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 314,
              src: 'blue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 176,
              hour_array: ["AOD_00.png","AOD_01.png","AOD_02.png","AOD_03.png","AOD_04.png","AOD_05.png","AOD_06.png","AOD_07.png","AOD_08.png","AOD_09.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 231,
              minute_startY: 175,
              minute_array: ["AOD_00.png","AOD_01.png","AOD_02.png","AOD_03.png","AOD_04.png","AOD_05.png","AOD_06.png","AOD_07.png","AOD_08.png","AOD_09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 184,
              src: 'AOD_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
