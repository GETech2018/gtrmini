﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_stand_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let idle_stand_icon_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 416,
              // h: 416,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: '1.png', path: 'main_rasp.png' },
                { id: 2, preview: '2.png', path: 'main_green.png' },
                { id: 3, preview: '3.png', path: 'main_blue.png' },
                { id: 4, preview: '4.png', path: 'main_orange.png' },
                { id: 5, preview: '5.png', path: 'main_perp.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: 'main_neon.png' },
                { id: 7, preview: '7.png', path: 'main_red.png' },
                { id: 8, preview: '8.png', path: 'main_white.png' },
                { id: 9, preview: '9.png', path: 'main_yellow.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 75,
              y: 83,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 181,
              day_startY: 41,
              day_sc_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              day_tc_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              day_en_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 354,
              font_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 299,
              font_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 299,
              font_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 147,
              hour_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 234,
              minute_startY: 147,
              minute_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 104,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 32,
              anim_size: 32,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 202,
              y: 170,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "column",
              anim_fps: 10,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_Second.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 22,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 153,
              y: 351,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 75,
              y: 83,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 181,
              day_startY: 41,
              day_sc_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              day_tc_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              day_en_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 354,
              font_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 299,
              font_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 299,
              font_array: ["Numbers_M_00.png","Numbers_M_01.png","Numbers_M_02.png","Numbers_M_03.png","Numbers_M_04.png","Numbers_M_05.png","Numbers_M_06.png","Numbers_M_07.png","Numbers_M_08.png","Numbers_M_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 147,
              hour_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 234,
              minute_startY: 147,
              minute_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 153,
              y: 351,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 147,
              w: 340,
              h: 122,
              src: 'click_e.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 298,
              w: 89,
              h: 46,
              src: 'click_e.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 66,
              y: 298,
              w: 136,
              h: 46,
              src: 'click_e.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
