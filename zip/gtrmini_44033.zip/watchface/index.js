﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 337,
              font_array: ["info_01.png","info_02.png","info_03.png","info_04.png","info_05.png","info_06.png","info_07.png","info_08.png","info_09.png","info_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 337,
              font_array: ["info_01.png","info_02.png","info_03.png","info_04.png","info_05.png","info_06.png","info_07.png","info_08.png","info_09.png","info_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'info_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 299,
              font_array: ["info_01.png","info_02.png","info_03.png","info_04.png","info_05.png","info_06.png","info_07.png","info_08.png","info_09.png","info_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'info_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 98,
              font_array: ["info_01.png","info_02.png","info_03.png","info_04.png","info_05.png","info_06.png","info_07.png","info_08.png","info_09.png","info_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 130,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 245,
              month_startY: 24,
              month_sc_array: ["mt_01.png","mt_02.png","mt_03.png","mt_04.png","mt_05.png","mt_06.png","mt_07.png","mt_08.png","mt_09.png","mt_10.png","mt_11.png","mt_12.png"],
              month_tc_array: ["mt_01.png","mt_02.png","mt_03.png","mt_04.png","mt_05.png","mt_06.png","mt_07.png","mt_08.png","mt_09.png","mt_10.png","mt_11.png","mt_12.png"],
              month_en_array: ["mt_01.png","mt_02.png","mt_03.png","mt_04.png","mt_05.png","mt_06.png","mt_07.png","mt_08.png","mt_09.png","mt_10.png","mt_11.png","mt_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 103,
              y: 24,
              week_en: ["wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png","wk_07.png"],
              week_tc: ["wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png","wk_07.png"],
              week_sc: ["wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png","wk_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 189,
              day_startY: 3,
              day_sc_array: ["info_01.png","info_02.png","info_03.png","info_04.png","info_05.png","info_06.png","info_07.png","info_08.png","info_09.png","info_10.png"],
              day_tc_array: ["info_01.png","info_02.png","info_03.png","info_04.png","info_05.png","info_06.png","info_07.png","info_08.png","info_09.png","info_10.png"],
              day_en_array: ["info_01.png","info_02.png","info_03.png","info_04.png","info_05.png","info_06.png","info_07.png","info_08.png","info_09.png","info_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 33,
              hour_startY: 163,
              hour_array: ["hm_01.png","hm_02.png","hm_03.png","hm_04.png","hm_05.png","hm_06.png","hm_07.png","hm_08.png","hm_09.png","hm_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 241,
              minute_startY: 163,
              minute_array: ["hm_01.png","hm_02.png","hm_03.png","hm_04.png","hm_05.png","hm_06.png","hm_07.png","hm_08.png","hm_09.png","hm_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}