﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let editableTimePointers = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 416,
              // h: 416,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'main1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'main2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'main3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'main4.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'main5.png' },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_bg: 'tip.png',
              tips_x: 72,
              tips_y: 232,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 203,
              y: 7,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 81,
              src: 'system_Alam.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 30,
              y: 250,
              w: 137,
              h: 25,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 284,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_symbo_02.png',
              unit_tc: 'Weather_symbo_02.png',
              unit_en: 'Weather_symbo_02.png',
              negative_image: 'Weather_symbo_01.png',
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 323,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 105,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 343,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 260,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 324,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'Act_Small_Font_01.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 279,
              y: 322,
              image_array: ["Zone01.png","Zone02.png","Zone03.png","Zone04.png","Zone05.png","Zone06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 255,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_font_KM.png',
              unit_tc: 'Act_font_KM.png',
              unit_en: 'Act_font_KM.png',
              imperial_unit_sc: 'Act_font_MI.png',
              imperial_unit_tc: 'Act_font_MI.png',
              imperial_unit_en: 'Act_font_MI.png',
              dot_image: 'Act_font_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 287,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'step_pointer.png',
              center_x: 327,
              center_y: 178,
              x: 16,
              y: 54,
              start_angle: 270,
              end_angle: 451,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 193,
              font_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 28,
              month_startY: 115,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 60,
              y: 183,
              week_en: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              week_tc: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              week_sc: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 73,
              day_startY: 145,
              day_sc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_tc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_en_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 79,
              am_y: 32,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 79,
              pm_y: 32,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 53,
              hour_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 194,
              minute_startY: 53,
              minute_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 269,
              second_startY: 69,
              second_array: ["Time_S_Font_01.png","Time_S_Font_02.png","Time_S_Font_03.png","Time_S_Font_04.png","Time_S_Font_05.png","Time_S_Font_06.png","Time_S_Font_07.png","Time_S_Font_08.png","Time_S_Font_09.png","Time_S_Font_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 203,
              y: 7,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 81,
              src: 'system_Alam.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 30,
              y: 250,
              w: 137,
              h: 25,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 284,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_symbo_02.png',
              unit_tc: 'Weather_symbo_02.png',
              unit_en: 'Weather_symbo_02.png',
              negative_image: 'Weather_symbo_01.png',
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 323,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 105,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 343,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 260,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 324,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'Act_Small_Font_01.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 279,
              y: 322,
              image_array: ["Zone01.png","Zone02.png","Zone03.png","Zone04.png","Zone05.png","Zone06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 255,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_font_KM.png',
              unit_tc: 'Act_font_KM.png',
              unit_en: 'Act_font_KM.png',
              imperial_unit_sc: 'Act_font_MI.png',
              imperial_unit_tc: 'Act_font_MI.png',
              imperial_unit_en: 'Act_font_MI.png',
              dot_image: 'Act_font_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 287,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'step_pointer.png',
              center_x: 327,
              center_y: 178,
              x: 16,
              y: 54,
              start_angle: 270,
              end_angle: 451,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 193,
              font_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 28,
              month_startY: 115,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 60,
              y: 183,
              week_en: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              week_tc: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              week_sc: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 73,
              day_startY: 145,
              day_sc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_tc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_en_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 79,
              am_y: 32,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 79,
              pm_y: 32,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 53,
              hour_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 194,
              minute_startY: 53,
              minute_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 269,
              second_startY: 69,
              second_array: ["Time_S_Font_01.png","Time_S_Font_02.png","Time_S_Font_03.png","Time_S_Font_04.png","Time_S_Font_05.png","Time_S_Font_06.png","Time_S_Font_07.png","Time_S_Font_08.png","Time_S_Font_09.png","Time_S_Font_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'hand_S1.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'hand_H1.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'hand_M1.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_S2_4.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'hand_H2.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_M2.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_S2_4.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'hand_H3.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_M3.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_S2_4.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_H4.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_M4.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_S5.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_H5.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_M5.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
                {
                  id: 6,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_S6.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_H6.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_M6.png',
                  },
                  preview: 'pointer_edit_6_preview.png',
                },
                {
                  id: 7,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_S7.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_H7.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_M7.png',
                  },
                  preview: 'pointer_edit_7_preview.png',
                },
                {
                  id: 8,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_S2_4.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_H8.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: 'Hand_M8.png',
                  },
                  preview: 'pointer_edit_8_preview.png',
                },
                {
                  id: 9,
                  second: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: '0_empty.png',
                  },
                  hour: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: '0_empty.png',
                  },
                  minute: {
                    centerX: 208,
                    centerY: 208,
                    posX: 31,
                    posY: 202,
                    path: '0_empty.png',
                  },
                  preview: 'bg_edit_1_preview.png',
                },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_x: 68,
              tips_y: 70,
              tips_bg: 'tip.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 268,
              y: 66,
              w: 49,
              h: 31,
              src: '0_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 58,
              w: 22,
              h: 39,
              src: '0_empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 86,
              y: 73,
              w: 27,
              h: 27,
              src: '0_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 107,
              w: 49,
              h: 55,
              src: '0_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 279,
              w: 91,
              h: 54,
              src: '0_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 261,
              w: 80,
              h: 42,
              src: '0_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 253,
              y: 354,
              w: 93,
              h: 43,
              src: '0_empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 253,
              y: 321,
              w: 94,
              h: 28,
              src: '0_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 292,
              y: 189,
              w: 71,
              h: 34,
              src: '0_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
