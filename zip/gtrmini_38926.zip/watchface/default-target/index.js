try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                let arc_progress_bg_img = '';
                let arc_progress_widget = '';
                let arc_progress_icon = '';
                let steps_button = '';
                let is_steps_visible = 1;
                let week_coord_x = 144;
                let date_coord_x = 228;
                let date_button_w = 126;
                let week_array = [
                    '2.png',
                    '3.png',
                    '4.png',
                    '5.png',
                    '6.png',
                    '7.png',
                    '8.png'
                ];
                let language = hmSetting.getLanguage();
                if (language == 18) {
                    week_coord_x = 156;
                    date_coord_x = 212;
                    date_button_w = 95;
                    week_array[0] = '65.png';
                    week_array[1] = '66.png';
                    week_array[2] = '67.png';
                    week_array[3] = '68.png';
                    week_array[4] = '69.png';
                    week_array[5] = '70.png';
                    week_array[6] = '71.png';
                }
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 416,
                    h: 416,
                    color: '0xFF000000',
                    radius: 208,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: week_coord_x,
                    y: 24,
                    week_en: week_array,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: date_coord_x,
                    day_startY: 30,
                    day_sc_array: [
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png'
                    ],
                    day_tc_array: [
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png'
                    ],
                    day_en_array: [
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                arc_progress_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 158,
                    y: 158,
                    src: '19.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                arc_progress_widget = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 208,
                    center_y: 208,
                    radius: 43,
                    start_angle: -145,
                    end_angle: 145,
                    color: 4290756543,
                    line_width: 14,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                arc_progress_icon = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 188,
                    y: 224,
                    src: '20.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 177,
                    y: 342,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '23.png',
                    unit_tc: '23.png',
                    unit_en: '23.png',
                    negative_image: '22.png',
                    invalid_image: '21.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 188,
                    y: 370,
                    image_array: [
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 208,
                    hour_centerY: 208,
                    hour_posX: 24,
                    hour_posY: 132,
                    hour_path: '53.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 208,
                    minute_centerY: 208,
                    minute_posX: 11,
                    minute_posY: 203,
                    minute_path: '54.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 208,
                    second_centerY: 208,
                    second_posX: 6,
                    second_posY: 210,
                    second_path: '55.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: week_coord_x,
                    y: 24,
                    week_en: week_array,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: date_coord_x,
                    day_startY: 30,
                    day_sc_array: [
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png'
                    ],
                    day_tc_array: [
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png'
                    ],
                    day_en_array: [
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 208,
                    hour_centerY: 208,
                    hour_posX: 24,
                    hour_posY: 132,
                    hour_path: '63.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 208,
                    minute_centerY: 208,
                    minute_posX: 11,
                    minute_posY: 203,
                    minute_path: '64.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                steps_button = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 158,
                    y: 158,
                    text: '',
                    w: 100,
                    h: 100,
                    normal_src: '72.png',
                    press_src: '72.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    click_func: () => {
                        hmApp.startApp({ url: 'activityAppScreen', native: true });
                    }
                });
                hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 308,
                    y: 158,
                    text: '',
                    w: 100,
                    h: 100,
                    normal_src: '72.png',
                    press_src: '72.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    longpress_func: () => {
                        is_steps_visible++;
                        if (is_steps_visible > 1) is_steps_visible = 0;
                        arc_progress_bg_img.setProperty(hmUI.prop.VISIBLE, is_steps_visible == 1);
                        arc_progress_widget.setProperty(hmUI.prop.VISIBLE, is_steps_visible == 1);
                        arc_progress_icon.setProperty(hmUI.prop.VISIBLE, is_steps_visible == 1);
                        steps_button.setProperty(hmUI.prop.VISIBLE, is_steps_visible == 1);
                    }
                });
                hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: week_coord_x,
                    y: 24,
                    text: '',
                    w: date_button_w,
                    h: 34,
                    normal_src: '72.png',
                    press_src: '72.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    click_func: () => {
                        hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
                    }
                });
                hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 177,
                    y: 342,
                    text: '',
                    w: 42,
                    h: 70,
                    normal_src: '72.png',
                    press_src: '72.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    click_func: () => {
                        hmApp.startApp({ url: 'WeatherScreen', native: true });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}