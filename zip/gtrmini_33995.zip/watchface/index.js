﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 286,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0046.png',
              unit_tc: '0046.png',
              unit_en: '0046.png',
              negative_image: '0048.png',
              invalid_image: '0047.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 199,
              y: 142,
              week_en: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              week_tc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              week_sc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 270,
              month_startY: 252,
              month_sc_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              month_tc_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              month_en_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 252,
              day_sc_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              day_tc_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              day_en_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: '0049.png',
              day_unit_tc: '0049.png',
              day_unit_en: '0049.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 67,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0050.png',
              unit_tc: '0050.png',
              unit_en: '0050.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 328,
              y: 295,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png","Preview.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 331,
              font_array: ["time_10.png","time_11.png","time_12.png","time_13.png","time_14.png","time_15.png","time_16.png","time_17.png","time_18.png","time_19.png"],
              padding: false,
              h_space: -4,
              dot_image: 't_ov.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 331,
              src: 'dig_sec_deg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 361,
              y: 138,
              src: '0044.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 363,
              y: 253,
              src: '0045.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 22,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 367,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 0,
              dot_image: '0043.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 112,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 371,
              am_y: 181,
              am_sc_path: '0040.png',
              am_en_path: '0040.png',
              pm_x: 371,
              pm_y: 181,
              pm_sc_path: '0041.png',
              pm_en_path: '0041.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 163,
              hour_startY: 179,
              hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 276,
              minute_startY: 179,
              minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 369,
              second_startY: 210,
              second_array: ["dig_20.png","dig_21.png","dig_22.png","dig_23.png","dig_24.png","dig_25.png","dig_26.png","dig_27.png","dig_28.png","dig_29.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 110,
              month_startY: 212,
              month_sc_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              month_tc_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              month_en_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 63,
              day_startY: 212,
              day_sc_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              day_tc_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              day_en_array: ["dig_30.png","dig_31.png","dig_32.png","dig_33.png","dig_34.png","dig_35.png","dig_36.png","dig_37.png","dig_38.png","dig_39.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: '0049.png',
              day_unit_tc: '0049.png',
              day_unit_en: '0049.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 38,
              y: 180,
              week_en: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              week_tc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              week_sc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 360,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0050.png',
              unit_tc: '0050.png',
              unit_en: '0050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 274,
              y: 248,
              src: '0044.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 273,
              y: 143,
              src: '0045.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 220,
              am_y: 146,
              am_sc_path: '0040.png',
              am_en_path: '0040.png',
              pm_x: 220,
              pm_y: 250,
              pm_sc_path: '0041.png',
              pm_en_path: '0041.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 192,
              hour_startY: 179,
              hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: 'sep.png',
              hour_unit_tc: 'sep.png',
              hour_unit_en: 'sep.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 271,
              minute_startY: 179,
              minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 228,
              y: 315,
              w: 96,
              h: 45,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 114,
              y: 33,
              w: 89,
              h: 89,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 369,
              y: 173,
              w: 49,
              h: 71,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 348,
              y: 248,
              w: 62,
              h: 45,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 223,
              y: 247,
              w: 89,
              h: 45,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 273,
              y: 172,
              w: 89,
              h: 71,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 162,
              y: 172,
              w: 89,
              h: 71,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 31,
              y: 163,
              w: 89,
              h: 89,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 228,
              y: 11,
              w: 89,
              h: 45,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 228,
              y: 95,
              w: 134,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}