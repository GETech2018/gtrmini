/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_digital_clock_img_hour3 = '';
		let normal_digital_clock_img_minute4 = '';
		let normal_digital_clock_img_second5 = '';
		let normal_date_img_date_week_img7 = '';
		let normal_date_current_date_monthday8 = '';
		let normal_date_img_date_month9 = '';
		let normal_background_bg_img11 = '';
		let normal_battery_current_text_img12 = '';
		let normal_background_bg_img14 = '';
		let normal_step_current_text_img15 = '';
		let normal_background_bg_img17 = '';
		let normal_heart_current_text_img18 = '';
		let normal_current_city_text20 = '';
		let normal_temperature_current_text_img21 = '';
		let normal_weather_image_progress_img_level22 = '';
		let normal_alarm_status24 = '';
		let normal_bt_status25 = '';
		let normal_heart_jumpable_img_click28 = '';
		let normal_step_jumpable_img_click29 = '';
		let normal_weather_jumpable_img_click30 = '';
		let normal_alarm_jumpable_img_click31 = '';
		let normal_countdown_jumpable_img_click32 = '';
		let normal_stopwatch_jumpable_img_click33 = '';
		let normal_stress_jumpable_img_click34 = '';
		let normal_sunrise_jumpable_img_click35 = '';
		let normal_sleep_jumpable_img_click36 = '';
		let normal_temperature_jumpable_img_click37 = '';
		let idle_background_bg_img39 = '';
		let idle_date_current_date_monthday41 = '';
		let idle_battery_pointer_progress_img_pointer43 = '';
		let idle_analog_clock_time_pointer_hour46 = '';
		let idle_analog_clock_time_pointer_minute47 = '';
		let idle_analog_clock_time_pointer_second48 = '';
		let idle_alarm_status51 = '';
		let idle_bt_status52 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 133,
					y: 92,
					w: 25,
					h: 110,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 261,
					y: 92,
					w: 25,
					h: 110,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 24,
					hour_startY: 111,
					hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_minute4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 152,
					minute_startY: 111,
					minute_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_second5 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 280,
					second_startY: 111,
					second_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img7 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 66,
					y: 43,
					week_en: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
					week_tc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
					week_sc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday8 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 144,
					day_startY: 24,
					day_sc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					day_tc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					day_en_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_month9 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 242,
					month_startY: 43,
					month_sc_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					month_tc_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					month_en_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					month_is_character: true,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 137,
					y: 355,
					w: 27,
					h: 50,
					src: '0062.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img12 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 177,
					y: 354,
					font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0073.png',
					unit_tc: '0073.png',
					unit_en: '0073.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 184,
					y: 219,
					w: 60,
					h: 60,
					src: '0074.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img15 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 251,
					y: 222,
					font_array: ["0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 218,
					w: 62,
					h: 62,
					src: '0085.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_text_img18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 73,
					y: 222,
					font_array: ["0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0096.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
				weather.addEventListener(hmSensor.event.CHANGE, function() {
					updateTexts();
				});

				normal_current_city_text20 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 111,
					y: 296,
					w: 147,
					h: 40,
					color: 0xA5A9A0,
					text_size: 35,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_text_img21 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 268,
					y: 286,
					font_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0108.png"],
					unit_tc: ["0108.png"],
					unit_en: ["0108.png"],
					negative_image: ["0107.png"],
					invalid_image: ["0109.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_image_progress_img_level22 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 40,
					y: 281,
					image_array: ["0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status24 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 0,
					y: 162,
					w: 24,
					h: 27,
					type: hmUI.system_status.CLOCK,
					src: '0139.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status25 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 93,
					y: 360,
					w: 16,
					h: 24,
					type: hmUI.system_status.DISCONNECT,
					src: '0140.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_jumpable_img_click28 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 31,
					y: 246,
					w: 150,
					h: 55,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_jumpable_img_click29 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 224,
					y: 246,
					w: 200,
					h: 55,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_jumpable_img_click30 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 48,
					y: 316,
					w: 150,
					h: 55,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_jumpable_img_click31 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 47,
					y: 115,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_jumpable_img_click32 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 183,
					y: 115,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stopwatch_jumpable_img_click33 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 319,
					y: 115,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STOP_WATCH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_jumpable_img_click34 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 201,
					y: 378,
					w: 189,
					h: 77,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_jumpable_img_click35 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 58,
					y: 0,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_jumpable_img_click36 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 266,
					y: 1,
					w: 136,
					h: 110,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_jumpable_img_click37 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 269,
					y: 316,
					w: 150,
					h: 55,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_background_bg_img39 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 416,
					h: 416,
					src: '0141.png',
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_current_date_monthday41 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 299,
					day_startY: 198,
					day_sc_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					day_tc_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					day_en_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_pointer_progress_img_pointer43 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0152.png',
					center_x: 129,
					center_y: 208,
					x: 17,
					y: 63,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_hour46 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0153.png',
					hour_centerX: 208,
					hour_centerY: 208,
					hour_posX: 34,
					hour_posY: 152,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_minute47 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0154.png',
					minute_centerX: 208,
					minute_centerY: 208,
					minute_posX: 35,
					minute_posY: 204,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_second48 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0155.png',
					second_centerX: 208,
					second_centerY: 208,
					second_posX: 26,
					second_posY: 208,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_alarm_status51 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 0,
					y: 162,
					w: 20,
					h: 24,
					type: hmUI.system_status.CLOCK,
					src: '0156.png',
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_bt_status52 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 93,
					y: 360,
					w: 16,
					h: 24,
					type: hmUI.system_status.DISCONNECT,
					src: '0140.png',
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTexts() {
					const weatherData = weather.getForecastWeather();
					normal_current_city_text20.setProperty(hmUI.prop.TEXT, weatherData.cityName)
				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTexts();

					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}